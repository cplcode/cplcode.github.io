void trampbegin(int len);
void trampush(char* from,int len);
char* trampend(int len);
char* bytexec(char*);
#define bytepush(var) trampush((char*)&var,sizeof(var))
/**/


#define _GNU_SOURCE

#define _FILE_OFFSET_BITS 64

#define _LARGE_FILES

#define printERR fprintf(stderr,"\r%s: PROGRAM HALTED  \n",errormessage);fflush(stderr)

/* #define __NO_INLINE__ ! why was it here ? */

#include <unistd.h>

#include <stdlib.h>
/*** typedef _Complex float __cfloat128 __attribute__ ((__mode__ (__TC__))); ununderstood ***/
/*** typedef __float128 _Float128; ununderstood ***/
/*** extern _Float128 strtof128 (const char *restrict __nptr,
			 char **restrict __endptr) ununderstood ***/
/*** extern _Float128 strtof128_l (const char *restrict __nptr,
			 char **restrict __endptr,
			 locale_t __loc) ununderstood ***/

#include <stdio.h>

#include <fcntl.h>

#include <math.h>
/*** enum ununderstood ***/
/*** {
 FP_INT_UPWARD =

 0,
 FP_INT_DOWNWARD =

 1,
 FP_INT_TOWARDZERO =

 2,
 FP_INT_TONEARESTFROMZERO =

 3,
 FP_INT_TONEAREST =

 4,
 }; ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 acosf128 (_Float128 __x) ;  extern _Float128 __acosf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 asinf128 (_Float128 __x) ;  extern _Float128 __asinf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atanf128 (_Float128 __x) ;  extern _Float128 __atanf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atan2f128 (_Float128 __y, _Float128 __x) ;  extern _Float128 __atan2f128 (_Float128 __y, _Float128 __x) ; ununderstood ***/
/*** extern _Float128 cosf128 (_Float128 __x) ;  extern _Float128 __cosf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 sinf128 (_Float128 __x) ;  extern _Float128 __sinf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 tanf128 (_Float128 __x) ;  extern _Float128 __tanf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 coshf128 (_Float128 __x) ;  extern _Float128 __coshf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 sinhf128 (_Float128 __x) ;  extern _Float128 __sinhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 tanhf128 (_Float128 __x) ;  extern _Float128 __tanhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 acoshf128 (_Float128 __x) ;  extern _Float128 __acoshf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 asinhf128 (_Float128 __x) ;  extern _Float128 __asinhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atanhf128 (_Float128 __x) ;  extern _Float128 __atanhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 expf128 (_Float128 __x) ;  extern _Float128 __expf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 frexpf128 (_Float128 __x, int *__exponent) ;  extern _Float128 __frexpf128 (_Float128 __x, int *__exponent) ; ununderstood ***/
/*** extern _Float128 ldexpf128 (_Float128 __x, int __exponent) ;  extern _Float128 __ldexpf128 (_Float128 __x, int __exponent) ; ununderstood ***/
/*** extern _Float128 logf128 (_Float128 __x) ;  extern _Float128 __logf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log10f128 (_Float128 __x) ;  extern _Float128 __log10f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 modff128 (_Float128 __x, _Float128 *__iptr) ;  extern _Float128 __modff128 (_Float128 __x, _Float128 *__iptr)  ; ununderstood ***/
/*** extern _Float128 exp10f128 (_Float128 __x) ;  extern _Float128 __exp10f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 expm1f128 (_Float128 __x) ;  extern _Float128 __expm1f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log1pf128 (_Float128 __x) ;  extern _Float128 __log1pf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 logbf128 (_Float128 __x) ;  extern _Float128 __logbf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 exp2f128 (_Float128 __x) ;  extern _Float128 __exp2f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log2f128 (_Float128 __x) ;  extern _Float128 __log2f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 powf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __powf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 sqrtf128 (_Float128 __x) ;  extern _Float128 __sqrtf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 hypotf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __hypotf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 cbrtf128 (_Float128 __x) ;  extern _Float128 __cbrtf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 ceilf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __ceilf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fabsf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __fabsf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 floorf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __floorf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmodf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __fmodf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 copysignf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __copysignf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 nanf128 (const char *__tagb) ;  extern _Float128 __nanf128 (const char *__tagb) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 j0f128 (_Float128) ;  extern _Float128 __j0f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 j1f128 (_Float128) ;  extern _Float128 __j1f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 jnf128 (int, _Float128) ;  extern _Float128 __jnf128 (int, _Float128) ; ununderstood ***/
/*** extern _Float128 y0f128 (_Float128) ;  extern _Float128 __y0f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 y1f128 (_Float128) ;  extern _Float128 __y1f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 ynf128 (int, _Float128) ;  extern _Float128 __ynf128 (int, _Float128) ; ununderstood ***/
/*** extern _Float128 erff128 (_Float128) ;  extern _Float128 __erff128 (_Float128) ; ununderstood ***/
/*** extern _Float128 erfcf128 (_Float128) ;  extern _Float128 __erfcf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 lgammaf128 (_Float128) ;  extern _Float128 __lgammaf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 tgammaf128 (_Float128) ;  extern _Float128 __tgammaf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 lgammaf128_r (_Float128, int *__signgamp) ;  extern _Float128 __lgammaf128_r (_Float128, int *__signgamp) ; ununderstood ***/
/*** extern _Float128 rintf128 (_Float128 __x) ;  extern _Float128 __rintf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 nextafterf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __nextafterf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 nextdownf128 (_Float128 __x) ;  extern _Float128 __nextdownf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 nextupf128 (_Float128 __x) ;  extern _Float128 __nextupf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 remainderf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __remainderf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 scalbnf128 (_Float128 __x, int __n) ;  extern _Float128 __scalbnf128 (_Float128 __x, int __n) ; ununderstood ***/
/*** extern _Float128 scalblnf128 (_Float128 __x, long int __n) ;  extern _Float128 __scalblnf128 (_Float128 __x, long int __n) ; ununderstood ***/
/*** extern _Float128 nearbyintf128 (_Float128 __x) ;  extern _Float128 __nearbyintf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 roundf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __roundf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 truncf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __truncf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 remquof128 (_Float128 __x, _Float128 __y, int *__quo) ;  extern _Float128 __remquof128 (_Float128 __x, _Float128 __y, int *__quo) ; ununderstood ***/
/*** extern _Float128 fdimf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __fdimf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 fmaxf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fmaxf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fminf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fminf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmaf128 (_Float128 __x, _Float128 __y, _Float128 __z) ;  extern _Float128 __fmaf128 (_Float128 __x, _Float128 __y, _Float128 __z) ; ununderstood ***/
/*** extern _Float128 roundevenf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __roundevenf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmaxmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fmaxmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fminmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fminmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 getpayloadf128 (const _Float128 *__x) ;  extern _Float128 __getpayloadf128 (const _Float128 *__x) ; ununderstood ***/
/*** extern _Float128 scalbf128 (_Float128 __x, _Float128 __n) ;  extern _Float128 __scalbf128 (_Float128 __x, _Float128 __n) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/

#include <limits.h>

#include <float.h>

#include <string.h>


#include <time.h>

#include <sys/time.h>

#include <sys/types.h>

#include <setjmp.h>

#include <errno.h>

#include <signal.h>
#ifdef nofenv
  #define feenableexcept(fpe)
  #define feclearexcept(fpe)
#else
  #include <fenv.h>
  #ifdef modfenv
    #include "feenableexceptosx.h"
  #endif
  #define fpe FE_INVALID | FE_OVERFLOW | FE_DIVBYZERO
#endif

extern char errortemp_[(80+1)];

struct arrptr{int l,h; ssize_t i; char *a;};struct dynptr{void* p; int t;};extern char INTERRUPT;
extern void (*traphandler)(const char *);
struct freefunc{struct freefunc *next; void (*f)(void *); void *ptr;};extern struct freefunc *freestack;

#define freemem(upto) while(freestack!=upto){freestack->f(freestack->ptr); freestack=freestack->next;}

#define atblockexit(name,func,p) name.f=func;name.ptr=p;name.next=freestack;freestack=&name

#define commablockexit(name,func,p) name.f=func,name.ptr=p,name.next=freestack,freestack=&name
extern void traprestore(void *ptr);
extern void condfree(void *ptr);
extern int friexecerror(char** s);
extern int (*friexec)(char** s);

#define mmovefrom(var,buf,type) *(type *)(buf)=*var

#define mmoveto(var,buf,type) *var=*(type *)(buf)

#define mainstart void default_traphandler(const char *errormessage){   if(errormessage[0]){     printERR;     freemem(NULL);     exit(EXIT_FAILURE);   }else{     freemem(NULL);     exit(EXIT_SUCCESS);   } } int main(int argc, char **argv){ struct freefunc* es; 			{struct sigaction act,oldact; act.sa_sigaction=trapsignal; sigemptyset(&act.sa_mask); act.sa_flags=SA_RESTART|SA_SIGINFO; sigaction(SIGSEGV,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGSEGV,&oldact,NULL); sigaction(SIGFPE,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGFPE,&oldact,NULL); sigaction(SIGILL,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGILL,&oldact,NULL); sigaction(SIGINT,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGINT,&oldact,NULL); /* \
{void (*sig)(int); \
if((sig=signal(SIGSEGV,trapsignal))!=SIG_DFL)signal(SIGSEGV,sig); \
if((sig=signal(SIGFPE,trapsignal))!=SIG_DFL)signal(SIGFPE,sig); \
if((sig=signal(SIGILL,trapsignal))!=SIG_DFL)signal(SIGILL,sig); \
if((sig=signal(SIGINT,trapsignal))!=SIG_DFL)signal(SIGINT,sig); \
*/ else {traphandler=default_traphandler;       freestack=NULL;       feenableexcept(fpe);      }; } es=freestack;
extern int dynptrerr(int type);
extern void *errmalloc(void);
extern void ioerr(FILE *fil);
extern void errfclose(void *voidf);
extern void errfopen(FILE **f, const char *name, int mode);
extern int scanrec(FILE *f, const char *format, void *var) ;
extern int scanbool(FILE *f, const char *format, int *var) ;
extern int myfgets(char *name, char *var, char *varend, FILE *f) ;
extern int mygetline(char *name, char **var, FILE *f) ;
extern void trapsignal(int signum, siginfo_t *info, void *ucontext);






/* INTEGER LIBRARY FUNCTION INTEGER[(int)rint](REAL x) */
/* INTEGER LIBRARY FUNCTION int[(int)](REAL x) */





/* to-do list
1) modificare STRUCTURED ARRAY in modo da evitare malloc quando possibile
2) separare il #define CPL da quello C
*/
/* rbmatmodtest -- Copyright 2000 Paolo Luchini */
/* http://CPLcode.net/Applications/Numerical/Multigrid/ */
/* */
/* test and usage example of the rbmatmod library */

/* Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. */

/* Run as, e.g.: rbmatmodtest 1 2 localhost & rbmatmodtest 2 2 localhost */

/* Parallel-computing extensions to the CPL language and ! */
/* definition of SHARED types.                           ! */
/* For usage see parallel.info.                          ! */
/*                                                       !  */
/* Copyright 1999-2021 Paolo Luchini http://CPLcode.net  ! */
/* See attached LICENSE.                                 ! */
/*                                                       ! */
/* Code maturity: green.                                 ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <sys/mman.h>

#include <sys/wait.h>

#include <sys/shm.h>


#define SHMPAGE 4194304
extern size_t shmavail;
extern char *shmaddr;
extern void *shmalloc(size_t size);
extern sigset_t oldmask;
extern void donothing(int signum);
extern void setup_signal_USR1();



#include <sys/socket.h>

#include <netinet/in.h>

#include <netinet/tcp.h>
/*** # error "Adjust your <bits/endian.h> defines"

	uint16_t window ununderstood ***/
/*** enum ununderstood ***/
/*** {
 TCP_NO_QUEUE,
 TCP_RECV_QUEUE,
 TCP_SEND_QUEUE,
 TCP_QUEUES_NR,
}; ununderstood ***/

#include <netdb.h>
extern int tcpserver(uint16_t port)
;
extern int tcpclient(const char *hostname, uint16_t port) 
;
extern int udpsocket(uint16_t myport, const char *hostname, uint16_t hostport) 
;







extern void barrier_free(void * ptr);
extern struct freefunc barrier_f;
extern volatile int *barrier_;



/* Transparently reshapes the operation of the CPL compiler so as to provide ! */
/* array bounds checking and more run-time checks, without any modifications ! */
/* to the original program (at the expense of a slower execution).           ! */
/* To activate, put "USE rtchecks" at the beginning of your program.         ! */
/* See infocpl rtchecks.                                                     ! */
/*                                                                           !  */
/* Copyright 1996-2022 Paolo Luchini http://CPLcode.net                      ! */
/* Released under the attached LICENSE.                                      ! */
/*                                                                           ! */
/* Code maturity: mostly green but the TRACE command is orange.              ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <sys/ioctl.h>                                                          
/*
<*#ifdef __GNUC__
  const
#endif
int cb(int lb, int ub, int index);
#ifdef __GNUC__
  const
#endif
char* cp(int inputpos);
#ifdef __GNUC__
  const
#endif
char *cr(char *lb, char *ub, char *index);
*>
*/
/* nota: #ifdef non passa in C SECTION */
#undef printERR
#define printERR fprintf(stderr,"\r%s in line %d of %s: PROGRAM HALTED  \n",errormessage,ln,fn);fflush(stderr)
extern volatile int ln;
extern char * volatile fn;
extern const int cb(int lb, int ub, int index);
extern const char * cp(void);
extern const int ca(void);
extern const unsigned char sigNAN[8];


/* CPL interface to the termios functions needed to turn on and off ! */
/* character-by-character terminal input                            ! */
/*                                                                  ! */
/* Copyright 2002-2021 Paolo Luchini http://CPLcode.net             ! */
/* Released under the attached LICENSE.                             ! */
/*                                                                  ! */
/* Code maturity: green.                                            ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <termios.h>
void CHARbyCHAR_1CHARbyCHAR(int descr_);
void CHARbyCHAR_2LINEbyLINE(void);

extern struct termios CHARbyCHAR_CHARbyCHAR_newsetting;
extern struct termios CHARbyCHAR_CHARbyCHAR_oldsetting;

extern int CHARbyCHAR_CHARbyCHAR_CbCdescr;

extern void CHARbyCHAR_1CHARbyCHAR(int descr_);


extern void CHARbyCHAR_2LINEbyLINE(void);

/* Library providing an interface to the select system call ! */
/* in order to detect if input is waiting to be read.       ! */
/* See infocpl INPUTREADY.                                  ! */
/*                                                          !  */
/* Copyright 2008-2020 Paolo Luchini http://CPLcode.net     ! */
/* Released under the attached LICENSE.                     ! */
/*                                                          ! */
/* Code maturity: green.                                    ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

extern int fd_input_ready(int fd, int sec, int usec);








extern int BlockLevel;

void singlestepper(int lineN_,char *line_);






extern FILE *rtchecks_SingleStep_grabin;

extern int rtchecks_SingleStep_StopLevel;
extern char rtchecks_SingleStep_LoopCount[(ssize_t)sizeof(int)*(100+1)];
extern int rtchecks_SingleStep_LastLine;

extern int rtchecks_SingleStep_paused;

extern int rtchecks_SingleStep_lastfnlength;
extern int rtchecks_SingleStep_lastrow;

extern char *rtchecks_SingleStep_lastfn;

extern int rtchecks_SingleStep_termwidth;
extern int rtchecks_SingleStep_termheight;

extern char *rtchecks_SingleStep_hotkeys;


extern void rtchecks_SingleStep_1RestoreScroll(void);


extern void TRON(void);


extern void singlestepper(int lineN_,char *line_);


extern int iproc_;
extern int nproc_;

/* iproc=number of the present node; nproc=total number of (distributed) nodes. */
extern FILE *prev_;
extern FILE *next_;

    
/* rbmatmod -- Copyright 2000 Paolo Luchini */
/* http://CPLcode.net/Applications/Numerical/rbmatmod/ */
/* */
/* parallel implementation of banded LU decomposition */
/* performs the solution of a banded linear system by the same algorithm used */
/* in rbmat.cpl. Each node in sequence solves a portion of the system and passes */
/* boundary data to the next node. */

/* Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE. */


extern void rbmatmod_1LUdecompStep(const int A_l,const int A_h,const ssize_t A_i,char *A__);


extern void rbmatmod_2LeftLUDivStep1(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__,const int t_l,const int t_h,const ssize_t t_i,char *t__);




extern void rbmatmod_3LeftLUDivStep2(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__);




extern void rbmatmod_4RightLUDivStep1(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int t_l,const int t_h,const ssize_t t_i,char *t__,const int A_l,const int A_h,const ssize_t A_i,char *A__);


extern void rbmatmod_5RightLUDivStep2(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__);

extern ssize_t rbmatmodtest_1st;
extern char mat_[(ssize_t)sizeof(double)*(2-(-2)+1)*((10+2)+1)];
extern char x_[(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10];
extern ssize_t rbmatmodtest_4st;
extern char y_[(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10];
extern ssize_t rbmatmodtest_5st;
extern char t_[(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10];
extern ssize_t rbmatmodtest_6st;

extern double sum1_;

extern double sum2_;

void w_memfd_create(int argc,char **stack){
int result;int (*function)(const char *__name_,int __flags_);
const char *__name;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__flags,16+*stack,(ssize_t)sizeof(int));result=(*function)(__name,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_mlock2(int argc,char **stack){
int result;int (*function)(const void *__addr_,size_t __length_,int __flags_);
const void *__addr;size_t __length;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__length,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__flags,24+*stack,(ssize_t)sizeof(int));result=(*function)(__addr,__length,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_pkey_alloc(int argc,char **stack){
int result;int (*function)(int __flags_,int __access_rights_);
int __flags;int __access_rights;
mmoveto(&function,*stack,void*);
memcpy((void*)&__flags,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__access_rights,12+*stack,(ssize_t)sizeof(int));result=(*function)(__flags,__access_rights); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_pkey_set(int argc,char **stack){
int result;int (*function)(int __key_,int __access_rights_);
int __key;int __access_rights;
mmoveto(&function,*stack,void*);
memcpy((void*)&__key,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__access_rights,12+*stack,(ssize_t)sizeof(int));result=(*function)(__key,__access_rights); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_pkey_get(int argc,char **stack){
int result;int (*function)(int __key_);
int __key;
mmoveto(&function,*stack,void*);
memcpy((void*)&__key,8+*stack,(ssize_t)sizeof(int));result=(*function)(__key); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_pkey_mprotect(int argc,char **stack){
int result;int (*function)(void *__addr_,size_t __len_,int __prot_,int __pkey_);
void *__addr;size_t __len;int __prot;int __pkey;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__prot,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__pkey,28+*stack,(ssize_t)sizeof(int));result=(*function)(__addr,__len,__prot,__pkey); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_mmap(int argc,char **stack){
void *result;void *(*function)(void *__addr_,size_t __len_,int __prot_,int __flags_,int __fd_,__off64_t __offset_);
void *__addr;size_t __len;int __prot;int __flags;int __fd;__off64_t __offset;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__prot,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__flags,28+*stack,(ssize_t)sizeof(int));memcpy((void*)&__fd,32+*stack,(ssize_t)sizeof(int));memcpy((void*)&__offset,36+*stack,(ssize_t)sizeof(__off64_t));result=(*function)(__addr,__len,__prot,__flags,__fd,__offset); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),void *);}
void w_munmap(int argc,char **stack){
int result;int (*function)(void *__addr_,size_t __len_);
void *__addr;size_t __len;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(size_t));result=(*function)(__addr,__len); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_mprotect(int argc,char **stack){
int result;int (*function)(void *__addr_,size_t __len_,int __prot_);
void *__addr;size_t __len;int __prot;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__prot,24+*stack,(ssize_t)sizeof(int));result=(*function)(__addr,__len,__prot); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_msync(int argc,char **stack){
int result;int (*function)(void *__addr_,size_t __len_,int __flags_);
void *__addr;size_t __len;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__flags,24+*stack,(ssize_t)sizeof(int));result=(*function)(__addr,__len,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_madvise(int argc,char **stack){
int result;int (*function)(void *__addr_,size_t __len_,int __advice_);
void *__addr;size_t __len;int __advice;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__advice,24+*stack,(ssize_t)sizeof(int));result=(*function)(__addr,__len,__advice); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_mlock(int argc,char **stack){
int result;int (*function)(const void *__addr_,size_t __len_);
const void *__addr;size_t __len;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(size_t));result=(*function)(__addr,__len); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_mlockall(int argc,char **stack){
int result;int (*function)(int __flags_);
int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__flags,8+*stack,(ssize_t)sizeof(int));result=(*function)(__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_munlockall(int argc,char **stack){
int result;int (*function)(void);

mmoveto(&function,*stack,void*);
result=(*function)(); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_mincore(int argc,char **stack){
int result;int (*function)(void *__start_,size_t __len_,char *__vec_);
void *__start;size_t __len;char *__vec;
mmoveto(&function,*stack,void*);
memcpy((void*)&__start,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__vec,24+*stack,(ssize_t)sizeof(char*));result=(*function)(__start,__len,__vec); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_mremap(int argc,char **stack){
void *result;void *(*function)(void *__addr_,size_t __old_len_,size_t __new_len_,int __flags_);
void *__addr;size_t __old_len;size_t __new_len;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__old_len,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__new_len,24+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__flags,32+*stack,(ssize_t)sizeof(int));result=(*function)(__addr,__old_len,__new_len,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),void *);}
void w_remap_file_pages(int argc,char **stack){
int result;int (*function)(void *__start_,size_t __size_,int __prot_,size_t __pgoff_,int __flags_);
void *__start;size_t __size;int __prot;size_t __pgoff;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__start,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__size,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__prot,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__pgoff,28+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__flags,36+*stack,(ssize_t)sizeof(int));result=(*function)(__start,__size,__prot,__pgoff,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_shm_open(int argc,char **stack){
int result;int (*function)(const char *__name_,int __oflag_,mode_t __mode_);
const char *__name;int __oflag;mode_t __mode;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__oflag,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__mode,20+*stack,(ssize_t)sizeof(mode_t));result=(*function)(__name,__oflag,__mode); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_shm_unlink(int argc,char **stack){
int result;int (*function)(const char *__name_);
const char *__name;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__name); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_wait(int argc,char **stack){
__pid_t result;__pid_t (*function)(int *__stat_loc_);
int *__stat_loc;
mmoveto(&function,*stack,void*);
memcpy((void*)&__stat_loc,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__stat_loc); mmovefrom(&result,*stack-((ssize_t)sizeof(__pid_t)),__pid_t );}
void w_waitpid(int argc,char **stack){
__pid_t result;__pid_t (*function)(__pid_t __pid_,int *__stat_loc_,int __options_);
__pid_t __pid;int *__stat_loc;int __options;
mmoveto(&function,*stack,void*);
memcpy((void*)&__pid,8+*stack,(ssize_t)sizeof(__pid_t));memcpy((void*)&__stat_loc,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__options,24+*stack,(ssize_t)sizeof(int));result=(*function)(__pid,__stat_loc,__options); mmovefrom(&result,*stack-((ssize_t)sizeof(__pid_t)),__pid_t );}
void w_waitid(int argc,char **stack){
int result;int (*function)(idtype_t __idtype_,__id_t __id_,siginfo_t *__infop_,int __options_);
idtype_t __idtype;__id_t __id;siginfo_t *__infop;int __options;
mmoveto(&function,*stack,void*);
memcpy((void*)&__idtype,8+*stack,(ssize_t)sizeof(idtype_t));memcpy((void*)&__id,16+*stack,(ssize_t)sizeof(__id_t));memcpy((void*)&__infop,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__options,32+*stack,(ssize_t)sizeof(int));result=(*function)(__idtype,__id,__infop,__options); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_wait3(int argc,char **stack){
__pid_t result;__pid_t (*function)(int *__stat_loc_,int __options_,struct rusage *__usage_);
int *__stat_loc;int __options;struct rusage *__usage;
mmoveto(&function,*stack,void*);
memcpy((void*)&__stat_loc,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__options,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__usage,20+*stack,(ssize_t)sizeof(char*));result=(*function)(__stat_loc,__options,__usage); mmovefrom(&result,*stack-((ssize_t)sizeof(__pid_t)),__pid_t );}
void w_wait4(int argc,char **stack){
__pid_t result;__pid_t (*function)(__pid_t __pid_,int *__stat_loc_,int __options_,struct rusage *__usage_);
__pid_t __pid;int *__stat_loc;int __options;struct rusage *__usage;
mmoveto(&function,*stack,void*);
memcpy((void*)&__pid,8+*stack,(ssize_t)sizeof(__pid_t));memcpy((void*)&__stat_loc,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__options,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__usage,28+*stack,(ssize_t)sizeof(char*));result=(*function)(__pid,__stat_loc,__options,__usage); mmovefrom(&result,*stack-((ssize_t)sizeof(__pid_t)),__pid_t );}
void w_ftok(int argc,char **stack){
key_t result;key_t (*function)(const char *__pathname_,int __proj_id_);
const char *__pathname;int __proj_id;
mmoveto(&function,*stack,void*);
memcpy((void*)&__pathname,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__proj_id,16+*stack,(ssize_t)sizeof(int));result=(*function)(__pathname,__proj_id); mmovefrom(&result,*stack-((ssize_t)sizeof(key_t)),key_t );}
void w_shmctl(int argc,char **stack){
int result;int (*function)(int __shmid_,int __cmd_,struct shmid_ds *__buf_);
int __shmid;int __cmd;struct shmid_ds *__buf;
mmoveto(&function,*stack,void*);
memcpy((void*)&__shmid,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__cmd,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&__buf,16+*stack,(ssize_t)sizeof(char*));result=(*function)(__shmid,__cmd,__buf); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_shmget(int argc,char **stack){
int result;int (*function)(key_t __key_,size_t __size_,int __shmflg_);
key_t __key;size_t __size;int __shmflg;
mmoveto(&function,*stack,void*);
memcpy((void*)&__key,8+*stack,(ssize_t)sizeof(key_t));memcpy((void*)&__size,16+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__shmflg,24+*stack,(ssize_t)sizeof(int));result=(*function)(__key,__size,__shmflg); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_shmat(int argc,char **stack){
void *result;void *(*function)(int __shmid_,const void *__shmaddr_,int __shmflg_);
int __shmid;const void *__shmaddr;int __shmflg;
mmoveto(&function,*stack,void*);
memcpy((void*)&__shmid,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__shmaddr,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__shmflg,20+*stack,(ssize_t)sizeof(int));result=(*function)(__shmid,__shmaddr,__shmflg); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),void *);}
void w_shmdt(int argc,char **stack){
int result;int (*function)(const void *__shmaddr_);
const void *__shmaddr;
mmoveto(&function,*stack,void*);
memcpy((void*)&__shmaddr,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__shmaddr); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_shmalloc(int argc,char **stack){
void *result;void *(*function)(size_t size_);
size_t size;
mmoveto(&function,*stack,void*);
memcpy((void*)&size,8+*stack,(ssize_t)sizeof(size_t));result=(*function)(size); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),void *);}
void w_donothing(int argc,char **stack){
void (*function)(int signum_);int signum;
mmoveto(&function,*stack,void*);
memcpy((void*)&signum,8+*stack,(ssize_t)sizeof(int));(*function)(signum);}
void w_setup_signal_USR1(int argc,char **stack){
void (*function)(void);
mmoveto(&function,*stack,void*);
(*function)();}
void w___cmsg_nxthdr(int argc,char **stack){
struct cmsghdr *result;struct cmsghdr *(*function)(struct msghdr *__mhdr_,struct cmsghdr *__cmsg_);
struct msghdr *__mhdr;struct cmsghdr *__cmsg;
mmoveto(&function,*stack,void*);
memcpy((void*)&__mhdr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__cmsg,16+*stack,(ssize_t)sizeof(char*));result=(*function)(__mhdr,__cmsg); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct cmsghdr *);}
void w_socket(int argc,char **stack){
int result;int (*function)(int __domain_,int __type_,int __protocol_);
int __domain;int __type;int __protocol;
mmoveto(&function,*stack,void*);
memcpy((void*)&__domain,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__type,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&__protocol,16+*stack,(ssize_t)sizeof(int));result=(*function)(__domain,__type,__protocol); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_socketpair(int argc,char **stack){
int result;int (*function)(int __domain_,int __type_,int __protocol_,int *__fds_);
int __domain;int __type;int __protocol;int *__fds;
mmoveto(&function,*stack,void*);
memcpy((void*)&__domain,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__type,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&__protocol,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__fds,20+*stack,(ssize_t)sizeof(char*));result=(*function)(__domain,__type,__protocol,__fds); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_bind(int argc,char **stack){
int result;int (*function)(int __fd_,const struct sockaddr *__addr_,socklen_t __len_);
int __fd;const struct sockaddr *__addr;socklen_t __len;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__addr,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,20+*stack,(ssize_t)sizeof(socklen_t));result=(*function)(__fd,__addr,__len); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getsockname(int argc,char **stack){
int result;int (*function)(int __fd_,struct sockaddr *__addr_,socklen_t *__len_);
int __fd;struct sockaddr *__addr;socklen_t *__len;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__addr,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,20+*stack,(ssize_t)sizeof(char*));result=(*function)(__fd,__addr,__len); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_send(int argc,char **stack){
ssize_t result;ssize_t (*function)(int __fd_,const void *__buf_,size_t __n_,int __flags_);
int __fd;const void *__buf;size_t __n;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__buf,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__n,20+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__flags,28+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__buf,__n,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(ssize_t)),ssize_t );}
void w_recv(int argc,char **stack){
ssize_t result;ssize_t (*function)(int __fd_,void *__buf_,size_t __n_,int __flags_);
int __fd;void *__buf;size_t __n;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__buf,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__n,20+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__flags,28+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__buf,__n,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(ssize_t)),ssize_t );}
void w_sendto(int argc,char **stack){
ssize_t result;ssize_t (*function)(int __fd_,const void *__buf_,size_t __n_,int __flags_,const struct sockaddr *__addr_,socklen_t __addr_len_);
int __fd;const void *__buf;size_t __n;int __flags;const struct sockaddr *__addr;socklen_t __addr_len;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__buf,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__n,20+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__flags,28+*stack,(ssize_t)sizeof(int));memcpy((void*)&__addr,32+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__addr_len,40+*stack,(ssize_t)sizeof(socklen_t));result=(*function)(__fd,__buf,__n,__flags,__addr,__addr_len); mmovefrom(&result,*stack-((ssize_t)sizeof(ssize_t)),ssize_t );}
void w_recvfrom(int argc,char **stack){
ssize_t result;ssize_t (*function)(int __fd_,void *__buf_,size_t __n_,int __flags_,struct sockaddr *__addr_,socklen_t *__addr_len_);
int __fd;void *__buf;size_t __n;int __flags;struct sockaddr *__addr;socklen_t *__addr_len;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__buf,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__n,20+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__flags,28+*stack,(ssize_t)sizeof(int));memcpy((void*)&__addr,32+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__addr_len,40+*stack,(ssize_t)sizeof(char*));result=(*function)(__fd,__buf,__n,__flags,__addr,__addr_len); mmovefrom(&result,*stack-((ssize_t)sizeof(ssize_t)),ssize_t );}
void w_sendmsg(int argc,char **stack){
ssize_t result;ssize_t (*function)(int __fd_,const struct msghdr *__message_,int __flags_);
int __fd;const struct msghdr *__message;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__message,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__flags,20+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__message,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(ssize_t)),ssize_t );}
void w_sendmmsg(int argc,char **stack){
int result;int (*function)(int __fd_,struct mmsghdr *__vmessages_,int __vlen_,int __flags_);
int __fd;struct mmsghdr *__vmessages;int __vlen;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__vmessages,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__vlen,20+*stack,(ssize_t)sizeof(int));memcpy((void*)&__flags,24+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__vmessages,__vlen,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_recvmsg(int argc,char **stack){
ssize_t result;ssize_t (*function)(int __fd_,struct msghdr *__message_,int __flags_);
int __fd;struct msghdr *__message;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__message,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__flags,20+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__message,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(ssize_t)),ssize_t );}
void w_recvmmsg(int argc,char **stack){
int result;int (*function)(int __fd_,struct mmsghdr *__vmessages_,int __vlen_,int __flags_,struct timespec *__tmo_);
int __fd;struct mmsghdr *__vmessages;int __vlen;int __flags;struct timespec *__tmo;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__vmessages,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__vlen,20+*stack,(ssize_t)sizeof(int));memcpy((void*)&__flags,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__tmo,28+*stack,(ssize_t)sizeof(char*));result=(*function)(__fd,__vmessages,__vlen,__flags,__tmo); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getsockopt(int argc,char **stack){
int result;int (*function)(int __fd_,int __level_,int __optname_,void *__optval_,socklen_t *__optlen_);
int __fd;int __level;int __optname;void *__optval;socklen_t *__optlen;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__level,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&__optname,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__optval,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__optlen,28+*stack,(ssize_t)sizeof(char*));result=(*function)(__fd,__level,__optname,__optval,__optlen); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_setsockopt(int argc,char **stack){
int result;int (*function)(int __fd_,int __level_,int __optname_,const void *__optval_,socklen_t __optlen_);
int __fd;int __level;int __optname;const void *__optval;socklen_t __optlen;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__level,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&__optname,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__optval,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__optlen,28+*stack,(ssize_t)sizeof(socklen_t));result=(*function)(__fd,__level,__optname,__optval,__optlen); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_listen(int argc,char **stack){
int result;int (*function)(int __fd_,int __n_);
int __fd;int __n;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__n,12+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__n); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_accept(int argc,char **stack){
int result;int (*function)(int __fd_,struct sockaddr *__addr_,socklen_t *__addr_len_);
int __fd;struct sockaddr *__addr;socklen_t *__addr_len;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__addr,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__addr_len,20+*stack,(ssize_t)sizeof(char*));result=(*function)(__fd,__addr,__addr_len); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_accept4(int argc,char **stack){
int result;int (*function)(int __fd_,struct sockaddr *__addr_,socklen_t *__addr_len_,int __flags_);
int __fd;struct sockaddr *__addr;socklen_t *__addr_len;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__addr,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__addr_len,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__flags,28+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__addr,__addr_len,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_shutdown(int argc,char **stack){
int result;int (*function)(int __fd_,int __how_);
int __fd;int __how;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__how,12+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__how); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_sockatmark(int argc,char **stack){
int result;int (*function)(int __fd_);
int __fd;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));result=(*function)(__fd); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_isfdtype(int argc,char **stack){
int result;int (*function)(int __fd_,int __fdtype_);
int __fd;int __fdtype;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__fdtype,12+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__fdtype); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_ntohl(int argc,char **stack){
uint32_t result;uint32_t (*function)(uint32_t __netlong_);
uint32_t __netlong;
mmoveto(&function,*stack,void*);
memcpy((void*)&__netlong,8+*stack,(ssize_t)sizeof(uint32_t));result=(*function)(__netlong); mmovefrom(&result,*stack-((ssize_t)sizeof(uint32_t)),uint32_t );}
void w_ntohs(int argc,char **stack){
uint16_t result;uint16_t (*function)(uint16_t __netshort_);
uint16_t __netshort;
mmoveto(&function,*stack,void*);
memcpy((void*)&__netshort,8+*stack,(ssize_t)sizeof(uint16_t));result=(*function)(__netshort); mmovefrom(&result,*stack-((ssize_t)sizeof(uint16_t)),uint16_t );}
void w_htonl(int argc,char **stack){
uint32_t result;uint32_t (*function)(uint32_t __hostlong_);
uint32_t __hostlong;
mmoveto(&function,*stack,void*);
memcpy((void*)&__hostlong,8+*stack,(ssize_t)sizeof(uint32_t));result=(*function)(__hostlong); mmovefrom(&result,*stack-((ssize_t)sizeof(uint32_t)),uint32_t );}
void w_htons(int argc,char **stack){
uint16_t result;uint16_t (*function)(uint16_t __hostshort_);
uint16_t __hostshort;
mmoveto(&function,*stack,void*);
memcpy((void*)&__hostshort,8+*stack,(ssize_t)sizeof(uint16_t));result=(*function)(__hostshort); mmovefrom(&result,*stack-((ssize_t)sizeof(uint16_t)),uint16_t );}
void w_bindresvport(int argc,char **stack){
int result;int (*function)(int __sockfd_,struct sockaddr_in *__sock_in_);
int __sockfd;struct sockaddr_in *__sock_in;
mmoveto(&function,*stack,void*);
memcpy((void*)&__sockfd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__sock_in,12+*stack,(ssize_t)sizeof(char*));result=(*function)(__sockfd,__sock_in); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_bindresvport6(int argc,char **stack){
int result;int (*function)(int __sockfd_,struct sockaddr_in6 *__sock_in_);
int __sockfd;struct sockaddr_in6 *__sock_in;
mmoveto(&function,*stack,void*);
memcpy((void*)&__sockfd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__sock_in,12+*stack,(ssize_t)sizeof(char*));result=(*function)(__sockfd,__sock_in); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_option_space(int argc,char **stack){
int result;int (*function)(int __nbytes_);
int __nbytes;
mmoveto(&function,*stack,void*);
memcpy((void*)&__nbytes,8+*stack,(ssize_t)sizeof(int));result=(*function)(__nbytes); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_option_init(int argc,char **stack){
int result;int (*function)(void *__bp_,struct cmsghdr **__cmsgp_,int __type_);
void *__bp;struct cmsghdr **__cmsgp;int __type;
mmoveto(&function,*stack,void*);
memcpy((void*)&__bp,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__cmsgp,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__type,24+*stack,(ssize_t)sizeof(int));result=(*function)(__bp,__cmsgp,__type); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_option_append(int argc,char **stack){
int result;int (*function)(struct cmsghdr *__cmsg_,const uint8_t *__typep_,int __multx_,int __plusy_);
struct cmsghdr *__cmsg;const uint8_t *__typep;int __multx;int __plusy;
mmoveto(&function,*stack,void*);
memcpy((void*)&__cmsg,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__typep,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__multx,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__plusy,28+*stack,(ssize_t)sizeof(int));result=(*function)(__cmsg,__typep,__multx,__plusy); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_option_alloc(int argc,char **stack){
uint8_t *result;uint8_t *(*function)(struct cmsghdr *__cmsg_,int __datalen_,int __multx_,int __plusy_);
struct cmsghdr *__cmsg;int __datalen;int __multx;int __plusy;
mmoveto(&function,*stack,void*);
memcpy((void*)&__cmsg,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__datalen,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__multx,20+*stack,(ssize_t)sizeof(int));memcpy((void*)&__plusy,24+*stack,(ssize_t)sizeof(int));result=(*function)(__cmsg,__datalen,__multx,__plusy); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),uint8_t *);}
void w_inet6_option_next(int argc,char **stack){
int result;int (*function)(const struct cmsghdr *__cmsg_,uint8_t **__tptrp_);
const struct cmsghdr *__cmsg;uint8_t **__tptrp;
mmoveto(&function,*stack,void*);
memcpy((void*)&__cmsg,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__tptrp,16+*stack,(ssize_t)sizeof(char*));result=(*function)(__cmsg,__tptrp); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_option_find(int argc,char **stack){
int result;int (*function)(const struct cmsghdr *__cmsg_,uint8_t **__tptrp_,int __type_);
const struct cmsghdr *__cmsg;uint8_t **__tptrp;int __type;
mmoveto(&function,*stack,void*);
memcpy((void*)&__cmsg,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__tptrp,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__type,24+*stack,(ssize_t)sizeof(int));result=(*function)(__cmsg,__tptrp,__type); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_opt_init(int argc,char **stack){
int result;int (*function)(void *__extbuf_,socklen_t __extlen_);
void *__extbuf;socklen_t __extlen;
mmoveto(&function,*stack,void*);
memcpy((void*)&__extbuf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__extlen,16+*stack,(ssize_t)sizeof(socklen_t));result=(*function)(__extbuf,__extlen); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_opt_append(int argc,char **stack){
int result;int (*function)(void *__extbuf_,socklen_t __extlen_,int __offset_,uint8_t __type_,socklen_t __len_,uint8_t __align_,void **__databufp_);
void *__extbuf;socklen_t __extlen;int __offset;uint8_t __type;socklen_t __len;uint8_t __align;void **__databufp;
mmoveto(&function,*stack,void*);
memcpy((void*)&__extbuf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__extlen,16+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__offset,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__type,28+*stack,(ssize_t)sizeof(uint8_t));memcpy((void*)&__len,36+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__align,44+*stack,(ssize_t)sizeof(uint8_t));memcpy((void*)&__databufp,52+*stack,(ssize_t)sizeof(char*));result=(*function)(__extbuf,__extlen,__offset,__type,__len,__align,__databufp); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_opt_finish(int argc,char **stack){
int result;int (*function)(void *__extbuf_,socklen_t __extlen_,int __offset_);
void *__extbuf;socklen_t __extlen;int __offset;
mmoveto(&function,*stack,void*);
memcpy((void*)&__extbuf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__extlen,16+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__offset,24+*stack,(ssize_t)sizeof(int));result=(*function)(__extbuf,__extlen,__offset); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_opt_set_val(int argc,char **stack){
int result;int (*function)(void *__databuf_,int __offset_,void *__val_,socklen_t __vallen_);
void *__databuf;int __offset;void *__val;socklen_t __vallen;
mmoveto(&function,*stack,void*);
memcpy((void*)&__databuf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__offset,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__val,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__vallen,28+*stack,(ssize_t)sizeof(socklen_t));result=(*function)(__databuf,__offset,__val,__vallen); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_opt_next(int argc,char **stack){
int result;int (*function)(void *__extbuf_,socklen_t __extlen_,int __offset_,uint8_t *__typep_,socklen_t *__lenp_,void **__databufp_);
void *__extbuf;socklen_t __extlen;int __offset;uint8_t *__typep;socklen_t *__lenp;void **__databufp;
mmoveto(&function,*stack,void*);
memcpy((void*)&__extbuf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__extlen,16+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__offset,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__typep,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__lenp,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__databufp,44+*stack,(ssize_t)sizeof(char*));result=(*function)(__extbuf,__extlen,__offset,__typep,__lenp,__databufp); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_opt_find(int argc,char **stack){
int result;int (*function)(void *__extbuf_,socklen_t __extlen_,int __offset_,uint8_t __type_,socklen_t *__lenp_,void **__databufp_);
void *__extbuf;socklen_t __extlen;int __offset;uint8_t __type;socklen_t *__lenp;void **__databufp;
mmoveto(&function,*stack,void*);
memcpy((void*)&__extbuf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__extlen,16+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__offset,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__type,28+*stack,(ssize_t)sizeof(uint8_t));memcpy((void*)&__lenp,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__databufp,44+*stack,(ssize_t)sizeof(char*));result=(*function)(__extbuf,__extlen,__offset,__type,__lenp,__databufp); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_rth_space(int argc,char **stack){
socklen_t result;socklen_t (*function)(int __type_,int __segments_);
int __type;int __segments;
mmoveto(&function,*stack,void*);
memcpy((void*)&__type,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__segments,12+*stack,(ssize_t)sizeof(int));result=(*function)(__type,__segments); mmovefrom(&result,*stack-((ssize_t)sizeof(socklen_t)),socklen_t );}
void w_inet6_rth_init(int argc,char **stack){
void *result;void *(*function)(void *__bp_,socklen_t __bp_len_,int __type_,int __segments_);
void *__bp;socklen_t __bp_len;int __type;int __segments;
mmoveto(&function,*stack,void*);
memcpy((void*)&__bp,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__bp_len,16+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__type,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__segments,28+*stack,(ssize_t)sizeof(int));result=(*function)(__bp,__bp_len,__type,__segments); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),void *);}
void w_inet6_rth_add(int argc,char **stack){
int result;int (*function)(void *__bp_,const struct in6_addr *__addr_);
void *__bp;const struct in6_addr *__addr;
mmoveto(&function,*stack,void*);
memcpy((void*)&__bp,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__addr,16+*stack,(ssize_t)sizeof(char*));result=(*function)(__bp,__addr); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_rth_reverse(int argc,char **stack){
int result;int (*function)(const void *__in_,void *__out_);
const void *__in;void *__out;
mmoveto(&function,*stack,void*);
memcpy((void*)&__in,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__out,16+*stack,(ssize_t)sizeof(char*));result=(*function)(__in,__out); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_rth_segments(int argc,char **stack){
int result;int (*function)(const void *__bp_);
const void *__bp;
mmoveto(&function,*stack,void*);
memcpy((void*)&__bp,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__bp); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_inet6_rth_getaddr(int argc,char **stack){
struct in6_addr *result;struct in6_addr *(*function)(const void *__bp_,int __index_);
const void *__bp;int __index;
mmoveto(&function,*stack,void*);
memcpy((void*)&__bp,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__index,16+*stack,(ssize_t)sizeof(int));result=(*function)(__bp,__index); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct in6_addr *);}
void w_getipv4sourcefilter(int argc,char **stack){
int result;int (*function)(int __s_,struct in_addr __interface_addr_,struct in_addr __group_,uint32_t *__fmode_,uint32_t *__numsrc_,struct in_addr *__slist_);
int __s;struct in_addr __interface_addr;struct in_addr __group;uint32_t *__fmode;uint32_t *__numsrc;struct in_addr *__slist;
mmoveto(&function,*stack,void*);
memcpy((void*)&__s,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__interface_addr,12+*stack,(ssize_t)sizeof(struct in_addr));memcpy((void*)&__group,20+*stack,(ssize_t)sizeof(struct in_addr));memcpy((void*)&__fmode,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__numsrc,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__slist,44+*stack,(ssize_t)sizeof(char*));result=(*function)(__s,__interface_addr,__group,__fmode,__numsrc,__slist); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_setipv4sourcefilter(int argc,char **stack){
int result;int (*function)(int __s_,struct in_addr __interface_addr_,struct in_addr __group_,uint32_t __fmode_,uint32_t __numsrc_,const struct in_addr *__slist_);
int __s;struct in_addr __interface_addr;struct in_addr __group;uint32_t __fmode;uint32_t __numsrc;const struct in_addr *__slist;
mmoveto(&function,*stack,void*);
memcpy((void*)&__s,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__interface_addr,12+*stack,(ssize_t)sizeof(struct in_addr));memcpy((void*)&__group,20+*stack,(ssize_t)sizeof(struct in_addr));memcpy((void*)&__fmode,28+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__numsrc,36+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__slist,44+*stack,(ssize_t)sizeof(char*));result=(*function)(__s,__interface_addr,__group,__fmode,__numsrc,__slist); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getsourcefilter(int argc,char **stack){
int result;int (*function)(int __s_,uint32_t __interface_addr_,const struct sockaddr *__group_,socklen_t __grouplen_,uint32_t *__fmode_,uint32_t *__numsrc_,struct sockaddr_storage *__slist_);
int __s;uint32_t __interface_addr;const struct sockaddr *__group;socklen_t __grouplen;uint32_t *__fmode;uint32_t *__numsrc;struct sockaddr_storage *__slist;
mmoveto(&function,*stack,void*);
memcpy((void*)&__s,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__interface_addr,12+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__group,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__grouplen,28+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__fmode,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__numsrc,44+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__slist,52+*stack,(ssize_t)sizeof(char*));result=(*function)(__s,__interface_addr,__group,__grouplen,__fmode,__numsrc,__slist); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_setsourcefilter(int argc,char **stack){
int result;int (*function)(int __s_,uint32_t __interface_addr_,const struct sockaddr *__group_,socklen_t __grouplen_,uint32_t __fmode_,uint32_t __numsrc_,const struct sockaddr_storage *__slist_);
int __s;uint32_t __interface_addr;const struct sockaddr *__group;socklen_t __grouplen;uint32_t __fmode;uint32_t __numsrc;const struct sockaddr_storage *__slist;
mmoveto(&function,*stack,void*);
memcpy((void*)&__s,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__interface_addr,12+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__group,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__grouplen,28+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__fmode,36+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__numsrc,44+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__slist,52+*stack,(ssize_t)sizeof(char*));result=(*function)(__s,__interface_addr,__group,__grouplen,__fmode,__numsrc,__slist); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_setrpcent(int argc,char **stack){
void (*function)(int __stayopen_);int __stayopen;
mmoveto(&function,*stack,void*);
memcpy((void*)&__stayopen,8+*stack,(ssize_t)sizeof(int));(*function)(__stayopen);}
void w_getrpcbyname(int argc,char **stack){
struct rpcent *result;struct rpcent *(*function)(const char *__name_);
const char *__name;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__name); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct rpcent *);}
void w_getrpcbynumber(int argc,char **stack){
struct rpcent *result;struct rpcent *(*function)(int __number_);
int __number;
mmoveto(&function,*stack,void*);
memcpy((void*)&__number,8+*stack,(ssize_t)sizeof(int));result=(*function)(__number); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct rpcent *);}
void w_getrpcent(int argc,char **stack){
struct rpcent *result;struct rpcent *(*function)(void);

mmoveto(&function,*stack,void*);
result=(*function)(); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct rpcent *);}
void w_getrpcbyname_r(int argc,char **stack){
int result;int (*function)(const char *__name_,struct rpcent *__result_buf_,char *__buffer_,size_t __buflen_,struct rpcent **__result_);
const char *__name;struct rpcent *__result_buf;char *__buffer;size_t __buflen;struct rpcent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__result_buf,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buffer,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,32+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,40+*stack,(ssize_t)sizeof(char*));result=(*function)(__name,__result_buf,__buffer,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getrpcbynumber_r(int argc,char **stack){
int result;int (*function)(int __number_,struct rpcent *__result_buf_,char *__buffer_,size_t __buflen_,struct rpcent **__result_);
int __number;struct rpcent *__result_buf;char *__buffer;size_t __buflen;struct rpcent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__number,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__result_buf,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buffer,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,28+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,36+*stack,(ssize_t)sizeof(char*));result=(*function)(__number,__result_buf,__buffer,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getrpcent_r(int argc,char **stack){
int result;int (*function)(struct rpcent *__result_buf_,char *__buffer_,size_t __buflen_,struct rpcent **__result_);
struct rpcent *__result_buf;char *__buffer;size_t __buflen;struct rpcent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__result_buf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buffer,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,24+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,32+*stack,(ssize_t)sizeof(char*));result=(*function)(__result_buf,__buffer,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w___h_errno_location(int argc,char **stack){
int *result;int *(*function)(void);

mmoveto(&function,*stack,void*);
result=(*function)(); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),int *);}
void w_herror(int argc,char **stack){
void (*function)(const char *__str_);const char *__str;
mmoveto(&function,*stack,void*);
memcpy((void*)&__str,8+*stack,(ssize_t)sizeof(char*));(*function)(__str);}
void w_hstrerror(int argc,char **stack){
const char *result;const char *(*function)(int __err_num_);
int __err_num;
mmoveto(&function,*stack,void*);
memcpy((void*)&__err_num,8+*stack,(ssize_t)sizeof(int));result=(*function)(__err_num); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),const char *);}
void w_sethostent(int argc,char **stack){
void (*function)(int __stay_open_);int __stay_open;
mmoveto(&function,*stack,void*);
memcpy((void*)&__stay_open,8+*stack,(ssize_t)sizeof(int));(*function)(__stay_open);}
void w_gethostent(int argc,char **stack){
struct hostent *result;struct hostent *(*function)(void);

mmoveto(&function,*stack,void*);
result=(*function)(); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct hostent *);}
void w_gethostbyaddr(int argc,char **stack){
struct hostent *result;struct hostent *(*function)(const void *__addr_,__socklen_t __len_,int __type_);
const void *__addr;__socklen_t __len;int __type;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(__socklen_t));memcpy((void*)&__type,24+*stack,(ssize_t)sizeof(int));result=(*function)(__addr,__len,__type); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct hostent *);}
void w_gethostbyname(int argc,char **stack){
struct hostent *result;struct hostent *(*function)(const char *__name_);
const char *__name;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__name); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct hostent *);}
void w_gethostbyname2(int argc,char **stack){
struct hostent *result;struct hostent *(*function)(const char *__name_,int __af_);
const char *__name;int __af;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__af,16+*stack,(ssize_t)sizeof(int));result=(*function)(__name,__af); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct hostent *);}
void w_gethostent_r(int argc,char **stack){
int result;int (*function)(struct hostent *__result_buf_,char *__buf_,size_t __buflen_,struct hostent **__result_,int *__h_errnop_);
struct hostent *__result_buf;char *__buf;size_t __buflen;struct hostent **__result;int *__h_errnop;
mmoveto(&function,*stack,void*);
memcpy((void*)&__result_buf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,24+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,32+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__h_errnop,40+*stack,(ssize_t)sizeof(char*));result=(*function)(__result_buf,__buf,__buflen,__result,__h_errnop); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_gethostbyaddr_r(int argc,char **stack){
int result;int (*function)(const void *__addr_,__socklen_t __len_,int __type_,struct hostent *__result_buf_,char *__buf_,size_t __buflen_,struct hostent **__result_,int *__h_errnop_);
const void *__addr;__socklen_t __len;int __type;struct hostent *__result_buf;char *__buf;size_t __buflen;struct hostent **__result;int *__h_errnop;
mmoveto(&function,*stack,void*);
memcpy((void*)&__addr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__len,16+*stack,(ssize_t)sizeof(__socklen_t));memcpy((void*)&__type,24+*stack,(ssize_t)sizeof(int));memcpy((void*)&__result_buf,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,44+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,52+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__h_errnop,60+*stack,(ssize_t)sizeof(char*));result=(*function)(__addr,__len,__type,__result_buf,__buf,__buflen,__result,__h_errnop); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_gethostbyname_r(int argc,char **stack){
int result;int (*function)(const char *__name_,struct hostent *__result_buf_,char *__buf_,size_t __buflen_,struct hostent **__result_,int *__h_errnop_);
const char *__name;struct hostent *__result_buf;char *__buf;size_t __buflen;struct hostent **__result;int *__h_errnop;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__result_buf,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,32+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,40+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__h_errnop,48+*stack,(ssize_t)sizeof(char*));result=(*function)(__name,__result_buf,__buf,__buflen,__result,__h_errnop); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_gethostbyname2_r(int argc,char **stack){
int result;int (*function)(const char *__name_,int __af_,struct hostent *__result_buf_,char *__buf_,size_t __buflen_,struct hostent **__result_,int *__h_errnop_);
const char *__name;int __af;struct hostent *__result_buf;char *__buf;size_t __buflen;struct hostent **__result;int *__h_errnop;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__af,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__result_buf,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,36+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,44+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__h_errnop,52+*stack,(ssize_t)sizeof(char*));result=(*function)(__name,__af,__result_buf,__buf,__buflen,__result,__h_errnop); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getnetent(int argc,char **stack){
struct netent *result;struct netent *(*function)(void);

mmoveto(&function,*stack,void*);
result=(*function)(); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct netent *);}
void w_getnetbyaddr(int argc,char **stack){
struct netent *result;struct netent *(*function)(uint32_t __net_,int __type_);
uint32_t __net;int __type;
mmoveto(&function,*stack,void*);
memcpy((void*)&__net,8+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__type,16+*stack,(ssize_t)sizeof(int));result=(*function)(__net,__type); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct netent *);}
void w_getnetbyname(int argc,char **stack){
struct netent *result;struct netent *(*function)(const char *__name_);
const char *__name;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__name); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct netent *);}
void w_getnetent_r(int argc,char **stack){
int result;int (*function)(struct netent *__result_buf_,char *__buf_,size_t __buflen_,struct netent **__result_,int *__h_errnop_);
struct netent *__result_buf;char *__buf;size_t __buflen;struct netent **__result;int *__h_errnop;
mmoveto(&function,*stack,void*);
memcpy((void*)&__result_buf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,24+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,32+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__h_errnop,40+*stack,(ssize_t)sizeof(char*));result=(*function)(__result_buf,__buf,__buflen,__result,__h_errnop); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getnetbyaddr_r(int argc,char **stack){
int result;int (*function)(uint32_t __net_,int __type_,struct netent *__result_buf_,char *__buf_,size_t __buflen_,struct netent **__result_,int *__h_errnop_);
uint32_t __net;int __type;struct netent *__result_buf;char *__buf;size_t __buflen;struct netent **__result;int *__h_errnop;
mmoveto(&function,*stack,void*);
memcpy((void*)&__net,8+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__type,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__result_buf,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,36+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,44+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__h_errnop,52+*stack,(ssize_t)sizeof(char*));result=(*function)(__net,__type,__result_buf,__buf,__buflen,__result,__h_errnop); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getnetbyname_r(int argc,char **stack){
int result;int (*function)(const char *__name_,struct netent *__result_buf_,char *__buf_,size_t __buflen_,struct netent **__result_,int *__h_errnop_);
const char *__name;struct netent *__result_buf;char *__buf;size_t __buflen;struct netent **__result;int *__h_errnop;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__result_buf,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,32+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,40+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__h_errnop,48+*stack,(ssize_t)sizeof(char*));result=(*function)(__name,__result_buf,__buf,__buflen,__result,__h_errnop); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getservent(int argc,char **stack){
struct servent *result;struct servent *(*function)(void);

mmoveto(&function,*stack,void*);
result=(*function)(); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct servent *);}
void w_getservbyname(int argc,char **stack){
struct servent *result;struct servent *(*function)(const char *__name_,const char *__proto_);
const char *__name;const char *__proto;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__proto,16+*stack,(ssize_t)sizeof(char*));result=(*function)(__name,__proto); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct servent *);}
void w_getservbyport(int argc,char **stack){
struct servent *result;struct servent *(*function)(int __port_,const char *__proto_);
int __port;const char *__proto;
mmoveto(&function,*stack,void*);
memcpy((void*)&__port,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__proto,12+*stack,(ssize_t)sizeof(char*));result=(*function)(__port,__proto); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct servent *);}
void w_getservent_r(int argc,char **stack){
int result;int (*function)(struct servent *__result_buf_,char *__buf_,size_t __buflen_,struct servent **__result_);
struct servent *__result_buf;char *__buf;size_t __buflen;struct servent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__result_buf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,24+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,32+*stack,(ssize_t)sizeof(char*));result=(*function)(__result_buf,__buf,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getservbyname_r(int argc,char **stack){
int result;int (*function)(const char *__name_,const char *__proto_,struct servent *__result_buf_,char *__buf_,size_t __buflen_,struct servent **__result_);
const char *__name;const char *__proto;struct servent *__result_buf;char *__buf;size_t __buflen;struct servent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__proto,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__result_buf,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,32+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,40+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,48+*stack,(ssize_t)sizeof(char*));result=(*function)(__name,__proto,__result_buf,__buf,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getservbyport_r(int argc,char **stack){
int result;int (*function)(int __port_,const char *__proto_,struct servent *__result_buf_,char *__buf_,size_t __buflen_,struct servent **__result_);
int __port;const char *__proto;struct servent *__result_buf;char *__buf;size_t __buflen;struct servent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__port,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__proto,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__result_buf,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,36+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,44+*stack,(ssize_t)sizeof(char*));result=(*function)(__port,__proto,__result_buf,__buf,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getprotoent(int argc,char **stack){
struct protoent *result;struct protoent *(*function)(void);

mmoveto(&function,*stack,void*);
result=(*function)(); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct protoent *);}
void w_getprotobyname(int argc,char **stack){
struct protoent *result;struct protoent *(*function)(const char *__name_);
const char *__name;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__name); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct protoent *);}
void w_getprotobynumber(int argc,char **stack){
struct protoent *result;struct protoent *(*function)(int __proto_);
int __proto;
mmoveto(&function,*stack,void*);
memcpy((void*)&__proto,8+*stack,(ssize_t)sizeof(int));result=(*function)(__proto); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),struct protoent *);}
void w_getprotoent_r(int argc,char **stack){
int result;int (*function)(struct protoent *__result_buf_,char *__buf_,size_t __buflen_,struct protoent **__result_);
struct protoent *__result_buf;char *__buf;size_t __buflen;struct protoent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__result_buf,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,24+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,32+*stack,(ssize_t)sizeof(char*));result=(*function)(__result_buf,__buf,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getprotobyname_r(int argc,char **stack){
int result;int (*function)(const char *__name_,struct protoent *__result_buf_,char *__buf_,size_t __buflen_,struct protoent **__result_);
const char *__name;struct protoent *__result_buf;char *__buf;size_t __buflen;struct protoent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__result_buf,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,32+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,40+*stack,(ssize_t)sizeof(char*));result=(*function)(__name,__result_buf,__buf,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getprotobynumber_r(int argc,char **stack){
int result;int (*function)(int __proto_,struct protoent *__result_buf_,char *__buf_,size_t __buflen_,struct protoent **__result_);
int __proto;struct protoent *__result_buf;char *__buf;size_t __buflen;struct protoent **__result;
mmoveto(&function,*stack,void*);
memcpy((void*)&__proto,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__result_buf,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buf,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,28+*stack,(ssize_t)sizeof(size_t));memcpy((void*)&__result,36+*stack,(ssize_t)sizeof(char*));result=(*function)(__proto,__result_buf,__buf,__buflen,__result); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_setnetgrent(int argc,char **stack){
int result;int (*function)(const char *__netgroup_);
const char *__netgroup;
mmoveto(&function,*stack,void*);
memcpy((void*)&__netgroup,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__netgroup); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getnetgrent(int argc,char **stack){
int result;int (*function)(char **__hostp_,char **__userp_,char **__domainp_);
char **__hostp;char **__userp;char **__domainp;
mmoveto(&function,*stack,void*);
memcpy((void*)&__hostp,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__userp,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__domainp,24+*stack,(ssize_t)sizeof(char*));result=(*function)(__hostp,__userp,__domainp); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_innetgr(int argc,char **stack){
int result;int (*function)(const char *__netgroup_,const char *__host_,const char *__user_,const char *__domain_);
const char *__netgroup;const char *__host;const char *__user;const char *__domain;
mmoveto(&function,*stack,void*);
memcpy((void*)&__netgroup,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__host,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__user,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__domain,32+*stack,(ssize_t)sizeof(char*));result=(*function)(__netgroup,__host,__user,__domain); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getnetgrent_r(int argc,char **stack){
int result;int (*function)(char **__hostp_,char **__userp_,char **__domainp_,char *__buffer_,size_t __buflen_);
char **__hostp;char **__userp;char **__domainp;char *__buffer;size_t __buflen;
mmoveto(&function,*stack,void*);
memcpy((void*)&__hostp,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__userp,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__domainp,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buffer,32+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__buflen,40+*stack,(ssize_t)sizeof(size_t));result=(*function)(__hostp,__userp,__domainp,__buffer,__buflen); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_rcmd(int argc,char **stack){
int result;int (*function)(char **__ahost_,int __rport_,const char *__locuser_,const char *__remuser_,const char *__cmd_,int *__fd2p_);
char **__ahost;int __rport;const char *__locuser;const char *__remuser;const char *__cmd;int *__fd2p;
mmoveto(&function,*stack,void*);
memcpy((void*)&__ahost,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__rport,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__locuser,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__remuser,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__cmd,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__fd2p,44+*stack,(ssize_t)sizeof(char*));result=(*function)(__ahost,__rport,__locuser,__remuser,__cmd,__fd2p); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_rcmd_af(int argc,char **stack){
int result;int (*function)(char **__ahost_,int __rport_,const char *__locuser_,const char *__remuser_,const char *__cmd_,int *__fd2p_,sa_family_t __af_);
char **__ahost;int __rport;const char *__locuser;const char *__remuser;const char *__cmd;int *__fd2p;sa_family_t __af;
mmoveto(&function,*stack,void*);
memcpy((void*)&__ahost,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__rport,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__locuser,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__remuser,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__cmd,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__fd2p,44+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__af,52+*stack,(ssize_t)sizeof(sa_family_t));result=(*function)(__ahost,__rport,__locuser,__remuser,__cmd,__fd2p,__af); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_rexec(int argc,char **stack){
int result;int (*function)(char **__ahost_,int __rport_,const char *__name_,const char *__pass_,const char *__cmd_,int *__fd2p_);
char **__ahost;int __rport;const char *__name;const char *__pass;const char *__cmd;int *__fd2p;
mmoveto(&function,*stack,void*);
memcpy((void*)&__ahost,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__rport,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__name,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__pass,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__cmd,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__fd2p,44+*stack,(ssize_t)sizeof(char*));result=(*function)(__ahost,__rport,__name,__pass,__cmd,__fd2p); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_rexec_af(int argc,char **stack){
int result;int (*function)(char **__ahost_,int __rport_,const char *__name_,const char *__pass_,const char *__cmd_,int *__fd2p_,sa_family_t __af_);
char **__ahost;int __rport;const char *__name;const char *__pass;const char *__cmd;int *__fd2p;sa_family_t __af;
mmoveto(&function,*stack,void*);
memcpy((void*)&__ahost,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__rport,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__name,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__pass,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__cmd,36+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__fd2p,44+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__af,52+*stack,(ssize_t)sizeof(sa_family_t));result=(*function)(__ahost,__rport,__name,__pass,__cmd,__fd2p,__af); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_ruserok(int argc,char **stack){
int result;int (*function)(const char *__rhost_,int __suser_,const char *__remuser_,const char *__locuser_);
const char *__rhost;int __suser;const char *__remuser;const char *__locuser;
mmoveto(&function,*stack,void*);
memcpy((void*)&__rhost,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__suser,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__remuser,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__locuser,28+*stack,(ssize_t)sizeof(char*));result=(*function)(__rhost,__suser,__remuser,__locuser); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_ruserok_af(int argc,char **stack){
int result;int (*function)(const char *__rhost_,int __suser_,const char *__remuser_,const char *__locuser_,sa_family_t __af_);
const char *__rhost;int __suser;const char *__remuser;const char *__locuser;sa_family_t __af;
mmoveto(&function,*stack,void*);
memcpy((void*)&__rhost,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__suser,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__remuser,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__locuser,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__af,36+*stack,(ssize_t)sizeof(sa_family_t));result=(*function)(__rhost,__suser,__remuser,__locuser,__af); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_iruserok(int argc,char **stack){
int result;int (*function)(uint32_t __raddr_,int __suser_,const char *__remuser_,const char *__locuser_);
uint32_t __raddr;int __suser;const char *__remuser;const char *__locuser;
mmoveto(&function,*stack,void*);
memcpy((void*)&__raddr,8+*stack,(ssize_t)sizeof(uint32_t));memcpy((void*)&__suser,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__remuser,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__locuser,28+*stack,(ssize_t)sizeof(char*));result=(*function)(__raddr,__suser,__remuser,__locuser); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_iruserok_af(int argc,char **stack){
int result;int (*function)(const void *__raddr_,int __suser_,const char *__remuser_,const char *__locuser_,sa_family_t __af_);
const void *__raddr;int __suser;const char *__remuser;const char *__locuser;sa_family_t __af;
mmoveto(&function,*stack,void*);
memcpy((void*)&__raddr,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__suser,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__remuser,20+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__locuser,28+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__af,36+*stack,(ssize_t)sizeof(sa_family_t));result=(*function)(__raddr,__suser,__remuser,__locuser,__af); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_rresvport(int argc,char **stack){
int result;int (*function)(int *__alport_);
int *__alport;
mmoveto(&function,*stack,void*);
memcpy((void*)&__alport,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__alport); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_rresvport_af(int argc,char **stack){
int result;int (*function)(int *__alport_,sa_family_t __af_);
int *__alport;sa_family_t __af;
mmoveto(&function,*stack,void*);
memcpy((void*)&__alport,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__af,16+*stack,(ssize_t)sizeof(sa_family_t));result=(*function)(__alport,__af); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getaddrinfo(int argc,char **stack){
int result;int (*function)(const char *__name_,const char *__service_,const struct addrinfo *__req_,struct addrinfo **__pai_);
const char *__name;const char *__service;const struct addrinfo *__req;struct addrinfo **__pai;
mmoveto(&function,*stack,void*);
memcpy((void*)&__name,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__service,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__req,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__pai,32+*stack,(ssize_t)sizeof(char*));result=(*function)(__name,__service,__req,__pai); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_freeaddrinfo(int argc,char **stack){
void (*function)(struct addrinfo *__ai_);struct addrinfo *__ai;
mmoveto(&function,*stack,void*);
memcpy((void*)&__ai,8+*stack,(ssize_t)sizeof(char*));(*function)(__ai);}
void w_gai_strerror(int argc,char **stack){
const char *result;const char *(*function)(int __ecode_);
int __ecode;
mmoveto(&function,*stack,void*);
memcpy((void*)&__ecode,8+*stack,(ssize_t)sizeof(int));result=(*function)(__ecode); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),const char *);}
void w_getnameinfo(int argc,char **stack){
int result;int (*function)(const struct sockaddr *__sa_,socklen_t __salen_,char *__host_,socklen_t __hostlen_,char *__serv_,socklen_t __servlen_,int __flags_);
const struct sockaddr *__sa;socklen_t __salen;char *__host;socklen_t __hostlen;char *__serv;socklen_t __servlen;int __flags;
mmoveto(&function,*stack,void*);
memcpy((void*)&__sa,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__salen,16+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__host,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__hostlen,32+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__serv,40+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__servlen,48+*stack,(ssize_t)sizeof(socklen_t));memcpy((void*)&__flags,56+*stack,(ssize_t)sizeof(int));result=(*function)(__sa,__salen,__host,__hostlen,__serv,__servlen,__flags); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_getaddrinfo_a(int argc,char **stack){
int result;int (*function)(int __mode_,struct gaicb **__list_,int __ent_,struct sigevent *__sig_);
int __mode;struct gaicb **__list;int __ent;struct sigevent *__sig;
mmoveto(&function,*stack,void*);
memcpy((void*)&__mode,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__list,12+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__ent,20+*stack,(ssize_t)sizeof(int));memcpy((void*)&__sig,24+*stack,(ssize_t)sizeof(char*));result=(*function)(__mode,__list,__ent,__sig); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_gai_suspend(int argc,char **stack){
int result;int (*function)(const struct gaicb **__list_,int __ent_,const struct timespec *__timeout_);
const struct gaicb **__list;int __ent;const struct timespec *__timeout;
mmoveto(&function,*stack,void*);
memcpy((void*)&__list,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__ent,16+*stack,(ssize_t)sizeof(int));memcpy((void*)&__timeout,20+*stack,(ssize_t)sizeof(char*));result=(*function)(__list,__ent,__timeout); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_gai_error(int argc,char **stack){
int result;int (*function)(struct gaicb *__req_);
struct gaicb *__req;
mmoveto(&function,*stack,void*);
memcpy((void*)&__req,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__req); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_gai_cancel(int argc,char **stack){
int result;int (*function)(struct gaicb *__gaicbp_);
struct gaicb *__gaicbp;
mmoveto(&function,*stack,void*);
memcpy((void*)&__gaicbp,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__gaicbp); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_tcpserver(int argc,char **stack){
int result;int (*function)(uint16_t port_);
uint16_t port;
mmoveto(&function,*stack,void*);
memcpy((void*)&port,8+*stack,(ssize_t)sizeof(uint16_t));result=(*function)(port); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_tcpclient(int argc,char **stack){
int result;int (*function)(const char *hostname_,uint16_t port_);
const char *hostname;uint16_t port;
mmoveto(&function,*stack,void*);
memcpy((void*)&hostname,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&port,16+*stack,(ssize_t)sizeof(uint16_t));result=(*function)(hostname,port); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_udpsocket(int argc,char **stack){
int result;int (*function)(uint16_t myport_,const char *hostname_,uint16_t hostport_);
uint16_t myport;const char *hostname;uint16_t hostport;
mmoveto(&function,*stack,void*);
memcpy((void*)&myport,8+*stack,(ssize_t)sizeof(uint16_t));memcpy((void*)&hostname,16+*stack,(ssize_t)sizeof(char*));memcpy((void*)&hostport,24+*stack,(ssize_t)sizeof(uint16_t));result=(*function)(myport,hostname,hostport); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_ioctl(int argc,char **stack){
int result;int (*function)(int __fd_,long __request_);
int __fd;long __request;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__request,12+*stack,(ssize_t)sizeof(long));result=(*function)(__fd,__request); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_cp(int argc,char **stack){
const char *result;const char *(*function)(void);

mmoveto(&function,*stack,void*);
result=(*function)(); mmovefrom(&result,*stack-((ssize_t)sizeof(char*)),const char *);}
void w_cfgetospeed(int argc,char **stack){
speed_t result;speed_t (*function)(const struct termios *__termios_p_);
const struct termios *__termios_p;
mmoveto(&function,*stack,void*);
memcpy((void*)&__termios_p,8+*stack,(ssize_t)sizeof(char*));result=(*function)(__termios_p); mmovefrom(&result,*stack-((ssize_t)sizeof(speed_t)),speed_t );}
void w_cfsetospeed(int argc,char **stack){
int result;int (*function)(struct termios *__termios_p_,speed_t __speed_);
struct termios *__termios_p;speed_t __speed;
mmoveto(&function,*stack,void*);
memcpy((void*)&__termios_p,8+*stack,(ssize_t)sizeof(char*));memcpy((void*)&__speed,16+*stack,(ssize_t)sizeof(speed_t));result=(*function)(__termios_p,__speed); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_tcgetattr(int argc,char **stack){
int result;int (*function)(int __fd_,struct termios *__termios_p_);
int __fd;struct termios *__termios_p;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__termios_p,12+*stack,(ssize_t)sizeof(char*));result=(*function)(__fd,__termios_p); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_tcsetattr(int argc,char **stack){
int result;int (*function)(int __fd_,int __optional_actions_,const struct termios *__termios_p_);
int __fd;int __optional_actions;const struct termios *__termios_p;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__optional_actions,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&__termios_p,16+*stack,(ssize_t)sizeof(char*));result=(*function)(__fd,__optional_actions,__termios_p); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_cfmakeraw(int argc,char **stack){
void (*function)(struct termios *__termios_p_);struct termios *__termios_p;
mmoveto(&function,*stack,void*);
memcpy((void*)&__termios_p,8+*stack,(ssize_t)sizeof(char*));(*function)(__termios_p);}
void w_tcsendbreak(int argc,char **stack){
int result;int (*function)(int __fd_,int __duration_);
int __fd;int __duration;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__duration,12+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__duration); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_tcflush(int argc,char **stack){
int result;int (*function)(int __fd_,int __queue_selector_);
int __fd;int __queue_selector;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__queue_selector,12+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__queue_selector); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_tcflow(int argc,char **stack){
int result;int (*function)(int __fd_,int __action_);
int __fd;int __action;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&__action,12+*stack,(ssize_t)sizeof(int));result=(*function)(__fd,__action); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_tcgetsid(int argc,char **stack){
__pid_t result;__pid_t (*function)(int __fd_);
int __fd;
mmoveto(&function,*stack,void*);
memcpy((void*)&__fd,8+*stack,(ssize_t)sizeof(int));result=(*function)(__fd); mmovefrom(&result,*stack-((ssize_t)sizeof(__pid_t)),__pid_t );}
void w_fd_input_ready(int argc,char **stack){
int result;int (*function)(int fd_,int sec_,int usec_);
int fd;int sec;int usec;
mmoveto(&function,*stack,void*);
memcpy((void*)&fd,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&sec,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&usec,16+*stack,(ssize_t)sizeof(int));result=(*function)(fd,sec,usec); mmovefrom(&result,*stack-((ssize_t)sizeof(int)),int );}
void w_barrier_free(int argc,char **stack){
void (*function)(void *ptr_);void *ptr;
mmoveto(&function,*stack,void*);
memcpy((void*)&ptr,8+*stack,(ssize_t)sizeof(char*));(*function)(ptr);}
void w_CHARbyCHAR_1CHARbyCHAR(int argc,char **stack){
void (*function)(int descr__);int descr_;
mmoveto(&function,*stack,void*);
memcpy((void*)&descr_,8+*stack,(ssize_t)sizeof(int));(*function)(descr_);}
void w_singlestepper(int argc,char **stack){
void (*function)(int lineN__,char *line__);int lineN_;char *line_;
mmoveto(&function,*stack,void*);
memcpy((void*)&lineN_,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&line_,12+*stack,(ssize_t)sizeof(char*));(*function)(lineN_,line_);}
void w_rbmatmod_1LUdecompStep(int argc,char **stack){
void (*function)(int A_l_,int A_h_,ssize_t A_i_,char *A___);int A_l;int A_h;ssize_t A_i;char *A__;
mmoveto(&function,*stack,void*);
memcpy((void*)&A_l,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&A_h,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&A_i,16+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&A__,24+*stack,(ssize_t)sizeof(char*));(*function)(A_l,A_h,A_i,A__);}
void w_rbmatmod_2LeftLUDivStep1(int argc,char **stack){
void (*function)(int x_l_,int x_h_,ssize_t x_i_,char *x___,int A_l_,int A_h_,ssize_t A_i_,char *A___,int t_l_,int t_h_,ssize_t t_i_,char *t___);int x_l;int x_h;ssize_t x_i;char *x__;int A_l;int A_h;ssize_t A_i;char *A__;int t_l;int t_h;ssize_t t_i;char *t__;
mmoveto(&function,*stack,void*);
memcpy((void*)&x_l,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&x_h,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&x_i,16+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&x__,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&A_l,32+*stack,(ssize_t)sizeof(int));memcpy((void*)&A_h,36+*stack,(ssize_t)sizeof(int));memcpy((void*)&A_i,40+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&A__,48+*stack,(ssize_t)sizeof(char*));memcpy((void*)&t_l,56+*stack,(ssize_t)sizeof(int));memcpy((void*)&t_h,60+*stack,(ssize_t)sizeof(int));memcpy((void*)&t_i,64+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&t__,72+*stack,(ssize_t)sizeof(char*));(*function)(x_l,x_h,x_i,x__,A_l,A_h,A_i,A__,t_l,t_h,t_i,t__);}
void w_rbmatmod_3LeftLUDivStep2(int argc,char **stack){
void (*function)(int x_l_,int x_h_,ssize_t x_i_,char *x___,int A_l_,int A_h_,ssize_t A_i_,char *A___);int x_l;int x_h;ssize_t x_i;char *x__;int A_l;int A_h;ssize_t A_i;char *A__;
mmoveto(&function,*stack,void*);
memcpy((void*)&x_l,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&x_h,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&x_i,16+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&x__,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&A_l,32+*stack,(ssize_t)sizeof(int));memcpy((void*)&A_h,36+*stack,(ssize_t)sizeof(int));memcpy((void*)&A_i,40+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&A__,48+*stack,(ssize_t)sizeof(char*));(*function)(x_l,x_h,x_i,x__,A_l,A_h,A_i,A__);}
void w_rbmatmod_4RightLUDivStep1(int argc,char **stack){
void (*function)(int x_l_,int x_h_,ssize_t x_i_,char *x___,int t_l_,int t_h_,ssize_t t_i_,char *t___,int A_l_,int A_h_,ssize_t A_i_,char *A___);int x_l;int x_h;ssize_t x_i;char *x__;int t_l;int t_h;ssize_t t_i;char *t__;int A_l;int A_h;ssize_t A_i;char *A__;
mmoveto(&function,*stack,void*);
memcpy((void*)&x_l,8+*stack,(ssize_t)sizeof(int));memcpy((void*)&x_h,12+*stack,(ssize_t)sizeof(int));memcpy((void*)&x_i,16+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&x__,24+*stack,(ssize_t)sizeof(char*));memcpy((void*)&t_l,32+*stack,(ssize_t)sizeof(int));memcpy((void*)&t_h,36+*stack,(ssize_t)sizeof(int));memcpy((void*)&t_i,40+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&t__,48+*stack,(ssize_t)sizeof(char*));memcpy((void*)&A_l,56+*stack,(ssize_t)sizeof(int));memcpy((void*)&A_h,60+*stack,(ssize_t)sizeof(int));memcpy((void*)&A_i,64+*stack,(ssize_t)sizeof(ssize_t));memcpy((void*)&A__,72+*stack,(ssize_t)sizeof(char*));(*function)(x_l,x_h,x_i,x__,t_l,t_h,t_i,t__,A_l,A_h,A_i,A__);}
