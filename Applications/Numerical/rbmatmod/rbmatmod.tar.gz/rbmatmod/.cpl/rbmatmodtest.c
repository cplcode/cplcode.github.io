/**/


#define _GNU_SOURCE

#define _FILE_OFFSET_BITS 64

#define _LARGE_FILES

#define printERR fprintf(stderr,"\r%s: PROGRAM HALTED  \n",errormessage);fflush(stderr)

/* #define __NO_INLINE__ ! why was it here ? */

#include <unistd.h>

#include <stdlib.h>
/*** typedef _Complex float __cfloat128 __attribute__ ((__mode__ (__TC__))); ununderstood ***/
/*** typedef __float128 _Float128; ununderstood ***/
/*** extern _Float128 strtof128 (const char *restrict __nptr,
			 char **restrict __endptr) ununderstood ***/
/*** extern _Float128 strtof128_l (const char *restrict __nptr,
			 char **restrict __endptr,
			 locale_t __loc) ununderstood ***/

#include <stdio.h>

#include <fcntl.h>

#include <math.h>
/*** enum ununderstood ***/
/*** {
 FP_INT_UPWARD =

 0,
 FP_INT_DOWNWARD =

 1,
 FP_INT_TOWARDZERO =

 2,
 FP_INT_TONEARESTFROMZERO =

 3,
 FP_INT_TONEAREST =

 4,
 }; ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 acosf128 (_Float128 __x) ;  extern _Float128 __acosf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 asinf128 (_Float128 __x) ;  extern _Float128 __asinf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atanf128 (_Float128 __x) ;  extern _Float128 __atanf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atan2f128 (_Float128 __y, _Float128 __x) ;  extern _Float128 __atan2f128 (_Float128 __y, _Float128 __x) ; ununderstood ***/
/*** extern _Float128 cosf128 (_Float128 __x) ;  extern _Float128 __cosf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 sinf128 (_Float128 __x) ;  extern _Float128 __sinf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 tanf128 (_Float128 __x) ;  extern _Float128 __tanf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 coshf128 (_Float128 __x) ;  extern _Float128 __coshf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 sinhf128 (_Float128 __x) ;  extern _Float128 __sinhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 tanhf128 (_Float128 __x) ;  extern _Float128 __tanhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 acoshf128 (_Float128 __x) ;  extern _Float128 __acoshf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 asinhf128 (_Float128 __x) ;  extern _Float128 __asinhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atanhf128 (_Float128 __x) ;  extern _Float128 __atanhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 expf128 (_Float128 __x) ;  extern _Float128 __expf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 frexpf128 (_Float128 __x, int *__exponent) ;  extern _Float128 __frexpf128 (_Float128 __x, int *__exponent) ; ununderstood ***/
/*** extern _Float128 ldexpf128 (_Float128 __x, int __exponent) ;  extern _Float128 __ldexpf128 (_Float128 __x, int __exponent) ; ununderstood ***/
/*** extern _Float128 logf128 (_Float128 __x) ;  extern _Float128 __logf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log10f128 (_Float128 __x) ;  extern _Float128 __log10f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 modff128 (_Float128 __x, _Float128 *__iptr) ;  extern _Float128 __modff128 (_Float128 __x, _Float128 *__iptr)  ; ununderstood ***/
/*** extern _Float128 exp10f128 (_Float128 __x) ;  extern _Float128 __exp10f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 expm1f128 (_Float128 __x) ;  extern _Float128 __expm1f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log1pf128 (_Float128 __x) ;  extern _Float128 __log1pf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 logbf128 (_Float128 __x) ;  extern _Float128 __logbf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 exp2f128 (_Float128 __x) ;  extern _Float128 __exp2f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log2f128 (_Float128 __x) ;  extern _Float128 __log2f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 powf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __powf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 sqrtf128 (_Float128 __x) ;  extern _Float128 __sqrtf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 hypotf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __hypotf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 cbrtf128 (_Float128 __x) ;  extern _Float128 __cbrtf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 ceilf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __ceilf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fabsf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __fabsf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 floorf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __floorf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmodf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __fmodf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 copysignf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __copysignf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 nanf128 (const char *__tagb) ;  extern _Float128 __nanf128 (const char *__tagb) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 j0f128 (_Float128) ;  extern _Float128 __j0f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 j1f128 (_Float128) ;  extern _Float128 __j1f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 jnf128 (int, _Float128) ;  extern _Float128 __jnf128 (int, _Float128) ; ununderstood ***/
/*** extern _Float128 y0f128 (_Float128) ;  extern _Float128 __y0f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 y1f128 (_Float128) ;  extern _Float128 __y1f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 ynf128 (int, _Float128) ;  extern _Float128 __ynf128 (int, _Float128) ; ununderstood ***/
/*** extern _Float128 erff128 (_Float128) ;  extern _Float128 __erff128 (_Float128) ; ununderstood ***/
/*** extern _Float128 erfcf128 (_Float128) ;  extern _Float128 __erfcf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 lgammaf128 (_Float128) ;  extern _Float128 __lgammaf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 tgammaf128 (_Float128) ;  extern _Float128 __tgammaf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 lgammaf128_r (_Float128, int *__signgamp) ;  extern _Float128 __lgammaf128_r (_Float128, int *__signgamp) ; ununderstood ***/
/*** extern _Float128 rintf128 (_Float128 __x) ;  extern _Float128 __rintf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 nextafterf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __nextafterf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 nextdownf128 (_Float128 __x) ;  extern _Float128 __nextdownf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 nextupf128 (_Float128 __x) ;  extern _Float128 __nextupf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 remainderf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __remainderf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 scalbnf128 (_Float128 __x, int __n) ;  extern _Float128 __scalbnf128 (_Float128 __x, int __n) ; ununderstood ***/
/*** extern _Float128 scalblnf128 (_Float128 __x, long int __n) ;  extern _Float128 __scalblnf128 (_Float128 __x, long int __n) ; ununderstood ***/
/*** extern _Float128 nearbyintf128 (_Float128 __x) ;  extern _Float128 __nearbyintf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 roundf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __roundf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 truncf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __truncf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 remquof128 (_Float128 __x, _Float128 __y, int *__quo) ;  extern _Float128 __remquof128 (_Float128 __x, _Float128 __y, int *__quo) ; ununderstood ***/
/*** extern _Float128 fdimf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __fdimf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 fmaxf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fmaxf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fminf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fminf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmaf128 (_Float128 __x, _Float128 __y, _Float128 __z) ;  extern _Float128 __fmaf128 (_Float128 __x, _Float128 __y, _Float128 __z) ; ununderstood ***/
/*** extern _Float128 roundevenf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __roundevenf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmaxmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fmaxmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fminmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fminmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 getpayloadf128 (const _Float128 *__x) ;  extern _Float128 __getpayloadf128 (const _Float128 *__x) ; ununderstood ***/
/*** extern _Float128 scalbf128 (_Float128 __x, _Float128 __n) ;  extern _Float128 __scalbf128 (_Float128 __x, _Float128 __n) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/

#include <limits.h>

#include <float.h>

#include <string.h>


#include <time.h>

#include <sys/time.h>

#include <sys/types.h>

#include <setjmp.h>

#include <errno.h>

#include <signal.h>
#ifdef nofenv
  #define feenableexcept(fpe)
  #define feclearexcept(fpe)
#else
  #include <fenv.h>
  #ifdef modfenv
    #include "feenableexceptosx.h"
  #endif
  #define fpe FE_INVALID | FE_OVERFLOW | FE_DIVBYZERO
#endif

extern char errortemp_[(80+1)];

struct arrptr{int l,h; ssize_t i; char *a;};struct dynptr{void* p; int t;};extern char INTERRUPT;
extern void (*traphandler)(const char *);
struct freefunc{struct freefunc *next; void (*f)(void *); void *ptr;};extern struct freefunc *freestack;

#define freemem(upto) while(freestack!=upto){freestack->f(freestack->ptr); freestack=freestack->next;}

#define atblockexit(name,func,p) name.f=func;name.ptr=p;name.next=freestack;freestack=&name

#define commablockexit(name,func,p) name.f=func,name.ptr=p,name.next=freestack,freestack=&name
extern void traprestore(void *ptr);
extern void condfree(void *ptr);
extern int friexecerror(char** s);
extern int (*friexec)(char** s);

#define mmovefrom(var,buf,type) *(type *)(buf)=*var

#define mmoveto(var,buf,type) *var=*(type *)(buf)

#define mainstart void default_traphandler(const char *errormessage){   if(errormessage[0]){     printERR;     freemem(NULL);     exit(EXIT_FAILURE);   }else{     freemem(NULL);     exit(EXIT_SUCCESS);   } } int main(int argc, char **argv){ struct freefunc* es; 			{struct sigaction act,oldact; act.sa_sigaction=trapsignal; sigemptyset(&act.sa_mask); act.sa_flags=SA_RESTART|SA_SIGINFO; sigaction(SIGSEGV,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGSEGV,&oldact,NULL); sigaction(SIGFPE,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGFPE,&oldact,NULL); sigaction(SIGILL,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGILL,&oldact,NULL); sigaction(SIGINT,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGINT,&oldact,NULL); /* \
{void (*sig)(int); \
if((sig=signal(SIGSEGV,trapsignal))!=SIG_DFL)signal(SIGSEGV,sig); \
if((sig=signal(SIGFPE,trapsignal))!=SIG_DFL)signal(SIGFPE,sig); \
if((sig=signal(SIGILL,trapsignal))!=SIG_DFL)signal(SIGILL,sig); \
if((sig=signal(SIGINT,trapsignal))!=SIG_DFL)signal(SIGINT,sig); \
*/ else {traphandler=default_traphandler;       freestack=NULL;       feenableexcept(fpe);      }; } es=freestack;
extern int dynptrerr(int type);
extern void *errmalloc(void);
extern void ioerr(FILE *fil);
extern void errfclose(void *voidf);
extern void errfopen(FILE **f, const char *name, int mode);
extern int scanrec(FILE *f, const char *format, void *var) ;
extern int scanbool(FILE *f, const char *format, int *var) ;
extern int myfgets(char *name, char *var, char *varend, FILE *f) ;
extern int mygetline(char *name, char **var, FILE *f) ;
extern void trapsignal(int signum, siginfo_t *info, void *ucontext);






/* INTEGER LIBRARY FUNCTION INTEGER[(int)rint](REAL x) */
/* INTEGER LIBRARY FUNCTION int[(int)](REAL x) */





/* to-do list
1) modificare STRUCTURED ARRAY in modo da evitare malloc quando possibile
2) separare il #define CPL da quello C
*/
/* rbmatmodtest -- Copyright 2000 Paolo Luchini */
/* http://CPLcode.net/Applications/Numerical/Multigrid/ */
/* */
/* test and usage example of the rbmatmod library */

/* Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. */

/* Run as, e.g.: rbmatmodtest 1 2 localhost & rbmatmodtest 2 2 localhost */

/* Parallel-computing extensions to the CPL language and ! */
/* definition of SHARED types.                           ! */
/* For usage see parallel.info.                          ! */
/*                                                       !  */
/* Copyright 1999-2021 Paolo Luchini http://CPLcode.net  ! */
/* See attached LICENSE.                                 ! */
/*                                                       ! */
/* Code maturity: green.                                 ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <sys/mman.h>

#include <sys/wait.h>

#include <sys/shm.h>


#define SHMPAGE 4194304
extern size_t shmavail;
extern char *shmaddr;
extern void *shmalloc(size_t size);
extern sigset_t oldmask;
extern void donothing(int signum);
extern void setup_signal_USR1();



#include <sys/socket.h>

#include <netinet/in.h>

#include <netinet/tcp.h>
/*** # error "Adjust your <bits/endian.h> defines"

	uint16_t window ununderstood ***/
/*** enum ununderstood ***/
/*** {
 TCP_NO_QUEUE,
 TCP_RECV_QUEUE,
 TCP_SEND_QUEUE,
 TCP_QUEUES_NR,
}; ununderstood ***/

#include <netdb.h>
extern int tcpserver(uint16_t port)
;
extern int tcpclient(const char *hostname, uint16_t port) 
;
extern int udpsocket(uint16_t myport, const char *hostname, uint16_t hostport) 
;







extern void barrier_free(void * ptr);
extern struct freefunc barrier_f;
extern volatile int *barrier_;



/* Transparently reshapes the operation of the CPL compiler so as to provide ! */
/* array bounds checking and more run-time checks, without any modifications ! */
/* to the original program (at the expense of a slower execution).           ! */
/* To activate, put "USE rtchecks" at the beginning of your program.         ! */
/* See infocpl rtchecks.                                                     ! */
/*                                                                           !  */
/* Copyright 1996-2022 Paolo Luchini http://CPLcode.net                      ! */
/* Released under the attached LICENSE.                                      ! */
/*                                                                           ! */
/* Code maturity: mostly green but the TRACE command is orange.              ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <sys/ioctl.h>                                                          
/*
<*#ifdef __GNUC__
  const
#endif
int cb(int lb, int ub, int index);
#ifdef __GNUC__
  const
#endif
char* cp(int inputpos);
#ifdef __GNUC__
  const
#endif
char *cr(char *lb, char *ub, char *index);
*>
*/
/* nota: #ifdef non passa in C SECTION */
#undef printERR
#define printERR fprintf(stderr,"\r%s in line %d of %s: PROGRAM HALTED  \n",errormessage,ln,fn);fflush(stderr)
extern volatile int ln;
extern char * volatile fn;
extern const int cb(int lb, int ub, int index);
extern const char * cp(void);
extern const int ca(void);
extern const unsigned char sigNAN[8];


/* CPL interface to the termios functions needed to turn on and off ! */
/* character-by-character terminal input                            ! */
/*                                                                  ! */
/* Copyright 2002-2021 Paolo Luchini http://CPLcode.net             ! */
/* Released under the attached LICENSE.                             ! */
/*                                                                  ! */
/* Code maturity: green.                                            ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <termios.h>
void CHARbyCHAR_1CHARbyCHAR(int descr_);
void CHARbyCHAR_2LINEbyLINE(void);

extern struct termios CHARbyCHAR_CHARbyCHAR_newsetting;
extern struct termios CHARbyCHAR_CHARbyCHAR_oldsetting;

extern int CHARbyCHAR_CHARbyCHAR_CbCdescr;

extern void CHARbyCHAR_1CHARbyCHAR(int descr_);


extern void CHARbyCHAR_2LINEbyLINE(void);

/* Library providing an interface to the select system call ! */
/* in order to detect if input is waiting to be read.       ! */
/* See infocpl INPUTREADY.                                  ! */
/*                                                          !  */
/* Copyright 2008-2020 Paolo Luchini http://CPLcode.net     ! */
/* Released under the attached LICENSE.                     ! */
/*                                                          ! */
/* Code maturity: green.                                    ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

extern int fd_input_ready(int fd, int sec, int usec);








extern int BlockLevel;

void singlestepper(int lineN_,char *line_);






extern FILE *rtchecks_SingleStep_grabin;

extern int rtchecks_SingleStep_StopLevel;
extern char rtchecks_SingleStep_LoopCount[(ssize_t)sizeof(int)*(100+1)];
extern int rtchecks_SingleStep_LastLine;

extern int rtchecks_SingleStep_paused;

extern int rtchecks_SingleStep_lastfnlength;
extern int rtchecks_SingleStep_lastrow;

extern char *rtchecks_SingleStep_lastfn;

extern int rtchecks_SingleStep_termwidth;
extern int rtchecks_SingleStep_termheight;

extern char *rtchecks_SingleStep_hotkeys;


extern void rtchecks_SingleStep_1RestoreScroll(void);


extern void TRON(void);


extern void singlestepper(int lineN_,char *line_);


/**/
int iproc_;
int nproc_;

/* iproc=number of the present node; nproc=total number of (distributed) nodes. */
FILE *prev_;
FILE *next_;

    
extern void rbmatmod_1LUdecompStep(const int A_l,const int A_h,const ssize_t A_i,char *A__);


extern void rbmatmod_2LeftLUDivStep1(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__,const int t_l,const int t_h,const ssize_t t_i,char *t__);




extern void rbmatmod_3LeftLUDivStep2(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__);




extern void rbmatmod_4RightLUDivStep1(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int t_l,const int t_h,const ssize_t t_i,char *t__,const int A_l,const int A_h,const ssize_t A_i,char *A__);


extern void rbmatmod_5RightLUDivStep2(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__);

ssize_t rbmatmodtest_1st;
char mat_[(ssize_t)sizeof(double)*(2-(-2)+1)*((10+2)+1)];
char x_[(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10];
ssize_t rbmatmodtest_4st;
char y_[(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10];
ssize_t rbmatmodtest_5st;
char t_[(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10];
ssize_t rbmatmodtest_6st;

double sum1_;

double sum2_;

mainstart
setup_signal_USR1();


barrier_=mmap(NULL,(ssize_t)sizeof(volatile int),PROT_READ|PROT_WRITE,MAP_SHARED|MAP_ANON,-1,0);if(barrier_==MAP_FAILED)errmalloc();atblockexit(barrier_f,barrier_free,(void*)barrier_);(*barrier_)=0;
CHARbyCHAR_CHARbyCHAR_CbCdescr= - 1;CHARbyCHAR_CHARbyCHAR_exit:;


rtchecks_SingleStep_grabin=NULL;rtchecks_SingleStep_grabin=NULL;rtchecks_SingleStep_StopLevel=INT_MAX;rtchecks_SingleStep_LastLine=0;(*(int *)(rtchecks_SingleStep_LoopCount))=1;
rtchecks_SingleStep_paused=0;rtchecks_SingleStep_lastfnlength=80;rtchecks_SingleStep_lastrow=1;rtchecks_SingleStep_lastfn=fn;rtchecks_SingleStep_termwidth=80;rtchecks_SingleStep_termheight=25;rtchecks_SingleStep_hotkeys="Tracing:(P)ause (Q)uit (T)roff (V)iew <tab>=(F)inish <C-c>=(I)cpl <space>=(S)tep";rtchecks_SingleStep_exit:;fn="/home/luchini/html/CPLcode.net/Applications/Numerical/rbmatmod/rbmatmodtest.cpl";ln=28;iproc_=1;ln=28;nproc_=1;ln=30;if( (argc-1)>0 ){ iproc_=atoi((*(char**)(cb(0,(argc-1),1)*(ssize_t)sizeof(char*)+(char*)argv))); nproc_=atoi((*(char**)(cb(0,(argc-1),2)*(ssize_t)sizeof(char*)+(char*)argv)));};

/* Open TCP sockets using the functions tcpserver and tcpclient provided in */
/* parallel.cpl. COMMANDLINE(3) is the hostname or ip of the next node; prev */
/* is listening for a similar connection from the previous node. */
prev_=NULL;next_=NULL;ln=36;/*bufsize=800*/
ln=37;/*baseport=(IPPORT_USERRESERVED+111)*/
ln=41;if( iproc_<nproc_ ){
  ln=39;next_=fdopen(tcpserver((IPPORT_USERRESERVED+111)+iproc_),"r+");
  ln=40;setvbuf(next_,malloc(800),_IOFBF,800);
};
ln=45;if( iproc_>1 ){
  ln=43;prev_=fdopen(tcpclient((*(char**)(cb(0,(argc-1),3)*(ssize_t)sizeof(char*)+(char*)argv)),(IPPORT_USERRESERVED+111)+iproc_-1),"r+");
  ln=44;setvbuf(prev_,malloc(800),_IOFBF,800);
};
fn="/home/luchini/html/CPLcode.net/Applications/Numerical/rbmatmod/rbmatmod.cpl";fn="/home/luchini/html/CPLcode.net/Applications/Numerical/rbmatmod/rbmatmodtest.cpl";

/* Allocate some matrix and random vectors */
ln=50;/*M=10*/
ln=51;/*N=10*/
ln=52;/*b=2*/
/* The unused elements of the first and last vector must be zeroed (at */
/* initialization only) because they will not be skipped. */
ln=55;rbmatmodtest_1st=(-2)*(ssize_t)sizeof(double);
{int i2;for(i2=0;i2<=(10+2);i2++){{int i3;for(i3=(-2);i3<=2;i3++){memmove((double *)(mat_-rbmatmodtest_1st+i2*(ssize_t)sizeof(double)*(2-(-2)+1)+i3*(ssize_t)sizeof(double)),&sigNAN,sizeof(double));}}}}ln=55;rbmatmodtest_4st=(ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st;
ln=55;memset(rbmatmodtest_4st+x_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st),0,(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10);ln=55;rbmatmodtest_5st=(ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st;
ln=55;memset(rbmatmodtest_5st+y_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st),0,(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10);ln=55;rbmatmodtest_6st=(ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st;
ln=55;memset(rbmatmodtest_6st+t_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st),0,(ssize_t)sizeof(double)*((10+2)-(-2)+1)*10);ln=56; {int i_=0  ;do{{ ln=56;(*(double *)(cb((-2),2,(-2)+0)*(ssize_t)sizeof(double)+cb(0,(10+2),i_)*(ssize_t)sizeof(double)*(2-(-2)+1)+mat_-rbmatmodtest_1st))=1.;(*(double *)(cb((-2),2,(-2)+1)*(ssize_t)sizeof(double)+cb(0,(10+2),i_)*(ssize_t)sizeof(double)*(2-(-2)+1)+mat_-rbmatmodtest_1st))=-4.;(*(double *)(cb((-2),2,(-2)+2)*(ssize_t)sizeof(double)+cb(0,(10+2),i_)*(ssize_t)sizeof(double)*(2-(-2)+1)+mat_-rbmatmodtest_1st))=6.;(*(double *)(cb((-2),2,(-2)+3)*(ssize_t)sizeof(double)+cb(0,(10+2),i_)*(ssize_t)sizeof(double)*(2-(-2)+1)+mat_-rbmatmodtest_1st))=-4.;(*(double *)(cb((-2),2,(-2)+4)*(ssize_t)sizeof(double)+cb(0,(10+2),i_)*(ssize_t)sizeof(double)*(2-(-2)+1)+mat_-rbmatmodtest_1st))=1.;}i_+=1;}while(i_<=10);}
ln=57;  {int m_=1;do{  {int i_=0  ;do{{ ln=57;(*(double *)(cb((-2),(10+2),i_)*(ssize_t)sizeof(double)+cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+x_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st)))=((double)(rand())/(double)(RAND_MAX));  (*(double *)(cb((-2),(10+2),i_)*(ssize_t)sizeof(double)+cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+y_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st)))=((double)(rand())/(double)(RAND_MAX)) ;}i_+=1;}while(i_<=10);}m_++;}while(m_<=10);}

/* parallel equivalent to LUdecomp mat (as defined in rbmat.cpl) */
ln=60;rbmatmod_1LUdecompStep(0,(10+2),(ssize_t)sizeof(double)*(2-(-2)+1),mat_-rbmatmodtest_1st);
/* parallel equivalent to t=mat\x (as defined in rbmat.cpl) */
ln=62;  {int m_=1;do{{ ln=62;rbmatmod_2LeftLUDivStep1((-2),(10+2),(ssize_t)sizeof(double),cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+t_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st),0,(10+2),(ssize_t)sizeof(double)*(2-(-2)+1),mat_-rbmatmodtest_1st,(-2),(10+2),(ssize_t)sizeof(double),cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+x_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st)) ;}m_++;}while(m_<=10);}
/* flush output buffer before switching from writing to reading on the  */
ln=64;{ ln=64;if( !((prev_==NULL)) ){ fflush(prev_);};};
ln=65;  {int m_=1;do{{ ln=65;rbmatmod_3LeftLUDivStep2((-2),(10+2),(ssize_t)sizeof(double),cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+t_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st),0,(10+2),(ssize_t)sizeof(double)*(2-(-2)+1),mat_-rbmatmodtest_1st) ;}m_++;}while(m_<=10);}
/* flush output buffer before switching from writing to reading  */
ln=67;{ ln=67;if( !((next_==NULL)) ){ fflush(next_);};};
/* parallel scalar product between t and y */
ln=69; sum1_=0.;  {int m_=1;do{  {int i_=0  ;do{{ln=69;(*&sum1_)+=(*(double *)(cb((-2),(10+2),i_)*(ssize_t)sizeof(double)+cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+t_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st)))*(*(double *)(cb((-2),(10+2),i_)*(ssize_t)sizeof(double)+cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+y_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st)) );}i_+=1;}while(i_<=10);}m_++;}while(m_<=10);}ln=70;if( !((prev_==NULL)) ){ double _7;
memmove(&_7,&sigNAN,sizeof(double));if(!(fread(0+&_7,(ssize_t)sizeof(double),1, prev_)==1))ioerr( prev_);
sum1_+=_7;};
ln=71;if( !((next_==NULL)) ){ fwrite(&sum1_,(ssize_t)sizeof(double),1,next_); fflush(next_ );}else{  fprintf(stdout,"%g""\n",sum1_);};
/* parallel equivalent to y=y/mat (as defined in rbmat.cpl) */
ln=73;  {int m_=1;do{{ ln=73;rbmatmod_4RightLUDivStep1((-2),(10+2),(ssize_t)sizeof(double),cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+y_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st),(-2),(10+2),(ssize_t)sizeof(double),cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+y_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st),0,(10+2),(ssize_t)sizeof(double)*(2-(-2)+1),mat_-rbmatmodtest_1st) ;}m_++;}while(m_<=10);}
ln=74;{ ln=74;if( !((prev_==NULL)) ){ fflush(prev_);};};
ln=75;  {int m_=1;do{{ ln=75;rbmatmod_5RightLUDivStep2((-2),(10+2),(ssize_t)sizeof(double),cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+y_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st),0,(10+2),(ssize_t)sizeof(double)*(2-(-2)+1),mat_-rbmatmodtest_1st) ;}m_++;}while(m_<=10);}
ln=76;{ ln=76;if( !((next_==NULL)) ){ fflush(next_);};};
/* parallel scalar product between x and y */
ln=78; sum2_=0.;  {int m_=1;do{  {int i_=0  ;do{{ln=78;(*&sum2_)+=(*(double *)(cb((-2),(10+2),i_)*(ssize_t)sizeof(double)+cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+x_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st)))*(*(double *)(cb((-2),(10+2),i_)*(ssize_t)sizeof(double)+cb(1,10,m_)*(ssize_t)sizeof(double)*((10+2)-(-2)+1)+y_-((ssize_t)sizeof(double)*((10+2)-(-2)+1)+rbmatmodtest_1st)) );}i_+=1;}while(i_<=10);}m_++;}while(m_<=10);}ln=79;if( !((prev_==NULL)) ){ double _8;
memmove(&_8,&sigNAN,sizeof(double));if(!(fread(0+&_8,(ssize_t)sizeof(double),1, prev_)==1))ioerr( prev_);
sum2_+=_8;};
ln=80;if( !((next_==NULL)) ){ fwrite(&sum2_,(ssize_t)sizeof(double),1,next_); fflush(next_ );}else{  fprintf(stdout,"%g""\n",sum2_);};
/* If the two products match, the test has been successful: y*mat\x = y/mat*x ! */
ln=82;if( fabs(1.-sum2_/sum1_)<1.e-7 ){  fprintf(stdout,"""success!""""\n");};
freemem(es);return 0;}
