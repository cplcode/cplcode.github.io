/**/


#define _GNU_SOURCE

#define _FILE_OFFSET_BITS 64

#define _LARGE_FILES

#define printERR fprintf(stderr,"\r%s: PROGRAM HALTED  \n",errormessage);fflush(stderr)

/* #define __NO_INLINE__ ! why was it here ? */

#include <unistd.h>

#include <stdlib.h>
/*** typedef _Complex float __cfloat128 __attribute__ ((__mode__ (__TC__))); ununderstood ***/
/*** typedef __float128 _Float128; ununderstood ***/
/*** extern _Float128 strtof128 (const char *restrict __nptr,
			 char **restrict __endptr) ununderstood ***/
/*** extern _Float128 strtof128_l (const char *restrict __nptr,
			 char **restrict __endptr,
			 locale_t __loc) ununderstood ***/

#include <stdio.h>

#include <fcntl.h>

#include <math.h>
/*** enum ununderstood ***/
/*** {
 FP_INT_UPWARD =

 0,
 FP_INT_DOWNWARD =

 1,
 FP_INT_TOWARDZERO =

 2,
 FP_INT_TONEARESTFROMZERO =

 3,
 FP_INT_TONEAREST =

 4,
 }; ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !0 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 acosf128 (_Float128 __x) ;  extern _Float128 __acosf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 asinf128 (_Float128 __x) ;  extern _Float128 __asinf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atanf128 (_Float128 __x) ;  extern _Float128 __atanf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atan2f128 (_Float128 __y, _Float128 __x) ;  extern _Float128 __atan2f128 (_Float128 __y, _Float128 __x) ; ununderstood ***/
/*** extern _Float128 cosf128 (_Float128 __x) ;  extern _Float128 __cosf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 sinf128 (_Float128 __x) ;  extern _Float128 __sinf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 tanf128 (_Float128 __x) ;  extern _Float128 __tanf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 coshf128 (_Float128 __x) ;  extern _Float128 __coshf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 sinhf128 (_Float128 __x) ;  extern _Float128 __sinhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 tanhf128 (_Float128 __x) ;  extern _Float128 __tanhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 acoshf128 (_Float128 __x) ;  extern _Float128 __acoshf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 asinhf128 (_Float128 __x) ;  extern _Float128 __asinhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 atanhf128 (_Float128 __x) ;  extern _Float128 __atanhf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 expf128 (_Float128 __x) ;  extern _Float128 __expf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 frexpf128 (_Float128 __x, int *__exponent) ;  extern _Float128 __frexpf128 (_Float128 __x, int *__exponent) ; ununderstood ***/
/*** extern _Float128 ldexpf128 (_Float128 __x, int __exponent) ;  extern _Float128 __ldexpf128 (_Float128 __x, int __exponent) ; ununderstood ***/
/*** extern _Float128 logf128 (_Float128 __x) ;  extern _Float128 __logf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log10f128 (_Float128 __x) ;  extern _Float128 __log10f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 modff128 (_Float128 __x, _Float128 *__iptr) ;  extern _Float128 __modff128 (_Float128 __x, _Float128 *__iptr)  ; ununderstood ***/
/*** extern _Float128 exp10f128 (_Float128 __x) ;  extern _Float128 __exp10f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 expm1f128 (_Float128 __x) ;  extern _Float128 __expm1f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log1pf128 (_Float128 __x) ;  extern _Float128 __log1pf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 logbf128 (_Float128 __x) ;  extern _Float128 __logbf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 exp2f128 (_Float128 __x) ;  extern _Float128 __exp2f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 log2f128 (_Float128 __x) ;  extern _Float128 __log2f128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 powf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __powf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 sqrtf128 (_Float128 __x) ;  extern _Float128 __sqrtf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 hypotf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __hypotf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 cbrtf128 (_Float128 __x) ;  extern _Float128 __cbrtf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 ceilf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __ceilf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fabsf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __fabsf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 floorf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __floorf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmodf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __fmodf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 copysignf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __copysignf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 nanf128 (const char *__tagb) ;  extern _Float128 __nanf128 (const char *__tagb) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** extern _Float128 j0f128 (_Float128) ;  extern _Float128 __j0f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 j1f128 (_Float128) ;  extern _Float128 __j1f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 jnf128 (int, _Float128) ;  extern _Float128 __jnf128 (int, _Float128) ; ununderstood ***/
/*** extern _Float128 y0f128 (_Float128) ;  extern _Float128 __y0f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 y1f128 (_Float128) ;  extern _Float128 __y1f128 (_Float128) ; ununderstood ***/
/*** extern _Float128 ynf128 (int, _Float128) ;  extern _Float128 __ynf128 (int, _Float128) ; ununderstood ***/
/*** extern _Float128 erff128 (_Float128) ;  extern _Float128 __erff128 (_Float128) ; ununderstood ***/
/*** extern _Float128 erfcf128 (_Float128) ;  extern _Float128 __erfcf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 lgammaf128 (_Float128) ;  extern _Float128 __lgammaf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 tgammaf128 (_Float128) ;  extern _Float128 __tgammaf128 (_Float128) ; ununderstood ***/
/*** extern _Float128 lgammaf128_r (_Float128, int *__signgamp) ;  extern _Float128 __lgammaf128_r (_Float128, int *__signgamp) ; ununderstood ***/
/*** extern _Float128 rintf128 (_Float128 __x) ;  extern _Float128 __rintf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 nextafterf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __nextafterf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 nextdownf128 (_Float128 __x) ;  extern _Float128 __nextdownf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 nextupf128 (_Float128 __x) ;  extern _Float128 __nextupf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 remainderf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __remainderf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 scalbnf128 (_Float128 __x, int __n) ;  extern _Float128 __scalbnf128 (_Float128 __x, int __n) ; ununderstood ***/
/*** extern _Float128 scalblnf128 (_Float128 __x, long int __n) ;  extern _Float128 __scalblnf128 (_Float128 __x, long int __n) ; ununderstood ***/
/*** extern _Float128 nearbyintf128 (_Float128 __x) ;  extern _Float128 __nearbyintf128 (_Float128 __x) ; ununderstood ***/
/*** extern _Float128 roundf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __roundf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 truncf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __truncf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 remquof128 (_Float128 __x, _Float128 __y, int *__quo) ;  extern _Float128 __remquof128 (_Float128 __x, _Float128 __y, int *__quo) ; ununderstood ***/
/*** extern _Float128 fdimf128 (_Float128 __x, _Float128 __y) ;  extern _Float128 __fdimf128 (_Float128 __x, _Float128 __y) ; ununderstood ***/
/*** extern _Float128 fmaxf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fmaxf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fminf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fminf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmaf128 (_Float128 __x, _Float128 __y, _Float128 __z) ;  extern _Float128 __fmaf128 (_Float128 __x, _Float128 __y, _Float128 __z) ; ununderstood ***/
/*** extern _Float128 roundevenf128 (_Float128 __x)  __attribute__ ((__const__));  extern _Float128 __roundevenf128 (_Float128 __x)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fmaxmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fmaxmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 fminmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__));  extern _Float128 __fminmagf128 (_Float128 __x, _Float128 __y)  __attribute__ ((__const__)); ununderstood ***/
/*** extern _Float128 getpayloadf128 (const _Float128 *__x) ;  extern _Float128 __getpayloadf128 (const _Float128 *__x) ; ununderstood ***/
/*** extern _Float128 scalbf128 (_Float128 __x, _Float128 __n) ;  extern _Float128 __scalbf128 (_Float128 __x, _Float128 __n) ; ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/
/*** && !1 ununderstood ***/

#include <limits.h>

#include <float.h>

#include <string.h>


#include <time.h>

#include <sys/time.h>

#include <sys/types.h>

#include <setjmp.h>

#include <errno.h>

#include <signal.h>
#ifdef nofenv
  #define feenableexcept(fpe)
  #define feclearexcept(fpe)
#else
  #include <fenv.h>
  #ifdef modfenv
    #include "feenableexceptosx.h"
  #endif
  #define fpe FE_INVALID | FE_OVERFLOW | FE_DIVBYZERO
#endif

extern char errortemp_[(80+1)];

struct arrptr{int l,h; ssize_t i; char *a;};struct dynptr{void* p; int t;};extern char INTERRUPT;
extern void (*traphandler)(const char *);
struct freefunc{struct freefunc *next; void (*f)(void *); void *ptr;};extern struct freefunc *freestack;

#define freemem(upto) while(freestack!=upto){freestack->f(freestack->ptr); freestack=freestack->next;}

#define atblockexit(name,func,p) name.f=func;name.ptr=p;name.next=freestack;freestack=&name

#define commablockexit(name,func,p) name.f=func,name.ptr=p,name.next=freestack,freestack=&name
extern void traprestore(void *ptr);
extern void condfree(void *ptr);
extern int friexecerror(char** s);
extern int (*friexec)(char** s);

#define mmovefrom(var,buf,type) *(type *)(buf)=*var

#define mmoveto(var,buf,type) *var=*(type *)(buf)

#define mainstart void default_traphandler(const char *errormessage){   if(errormessage[0]){     printERR;     freemem(NULL);     exit(EXIT_FAILURE);   }else{     freemem(NULL);     exit(EXIT_SUCCESS);   } } int main(int argc, char **argv){ struct freefunc* es; 			{struct sigaction act,oldact; act.sa_sigaction=trapsignal; sigemptyset(&act.sa_mask); act.sa_flags=SA_RESTART|SA_SIGINFO; sigaction(SIGSEGV,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGSEGV,&oldact,NULL); sigaction(SIGFPE,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGFPE,&oldact,NULL); sigaction(SIGILL,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGILL,&oldact,NULL); sigaction(SIGINT,&act,&oldact); if (oldact.sa_handler!=SIG_DFL)sigaction(SIGINT,&oldact,NULL); /* \
{void (*sig)(int); \
if((sig=signal(SIGSEGV,trapsignal))!=SIG_DFL)signal(SIGSEGV,sig); \
if((sig=signal(SIGFPE,trapsignal))!=SIG_DFL)signal(SIGFPE,sig); \
if((sig=signal(SIGILL,trapsignal))!=SIG_DFL)signal(SIGILL,sig); \
if((sig=signal(SIGINT,trapsignal))!=SIG_DFL)signal(SIGINT,sig); \
*/ else {traphandler=default_traphandler;       freestack=NULL;       feenableexcept(fpe);      }; } es=freestack;
extern int dynptrerr(int type);
extern void *errmalloc(void);
extern void ioerr(FILE *fil);
extern void errfclose(void *voidf);
extern void errfopen(FILE **f, const char *name, int mode);
extern int scanrec(FILE *f, const char *format, void *var) ;
extern int scanbool(FILE *f, const char *format, int *var) ;
extern int myfgets(char *name, char *var, char *varend, FILE *f) ;
extern int mygetline(char *name, char **var, FILE *f) ;
extern void trapsignal(int signum, siginfo_t *info, void *ucontext);






/* INTEGER LIBRARY FUNCTION INTEGER[(int)rint](REAL x) */
/* INTEGER LIBRARY FUNCTION int[(int)](REAL x) */





/* to-do list
1) modificare STRUCTURED ARRAY in modo da evitare malloc quando possibile
2) separare il #define CPL da quello C
*/
/* rbmatmodtest -- Copyright 2000 Paolo Luchini */
/* http://CPLcode.net/Applications/Numerical/Multigrid/ */
/* */
/* test and usage example of the rbmatmod library */

/* Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. */

/* Run as, e.g.: rbmatmodtest 1 2 localhost & rbmatmodtest 2 2 localhost */

/* Parallel-computing extensions to the CPL language and ! */
/* definition of SHARED types.                           ! */
/* For usage see parallel.info.                          ! */
/*                                                       !  */
/* Copyright 1999-2021 Paolo Luchini http://CPLcode.net  ! */
/* See attached LICENSE.                                 ! */
/*                                                       ! */
/* Code maturity: green.                                 ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <sys/mman.h>

#include <sys/wait.h>

#include <sys/shm.h>


#define SHMPAGE 4194304
extern size_t shmavail;
extern char *shmaddr;
extern void *shmalloc(size_t size);
extern sigset_t oldmask;
extern void donothing(int signum);
extern void setup_signal_USR1();



#include <sys/socket.h>

#include <netinet/in.h>

#include <netinet/tcp.h>
/*** # error "Adjust your <bits/endian.h> defines"

	uint16_t window ununderstood ***/
/*** enum ununderstood ***/
/*** {
 TCP_NO_QUEUE,
 TCP_RECV_QUEUE,
 TCP_SEND_QUEUE,
 TCP_QUEUES_NR,
}; ununderstood ***/

#include <netdb.h>
extern int tcpserver(uint16_t port)
;
extern int tcpclient(const char *hostname, uint16_t port) 
;
extern int udpsocket(uint16_t myport, const char *hostname, uint16_t hostport) 
;







extern void barrier_free(void * ptr);
extern struct freefunc barrier_f;
extern volatile int *barrier_;



/* Transparently reshapes the operation of the CPL compiler so as to provide ! */
/* array bounds checking and more run-time checks, without any modifications ! */
/* to the original program (at the expense of a slower execution).           ! */
/* To activate, put "USE rtchecks" at the beginning of your program.         ! */
/* See infocpl rtchecks.                                                     ! */
/*                                                                           !  */
/* Copyright 1996-2022 Paolo Luchini http://CPLcode.net                      ! */
/* Released under the attached LICENSE.                                      ! */
/*                                                                           ! */
/* Code maturity: mostly green but the TRACE command is orange.              ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <sys/ioctl.h>                                                          
/*
<*#ifdef __GNUC__
  const
#endif
int cb(int lb, int ub, int index);
#ifdef __GNUC__
  const
#endif
char* cp(int inputpos);
#ifdef __GNUC__
  const
#endif
char *cr(char *lb, char *ub, char *index);
*>
*/
/* nota: #ifdef non passa in C SECTION */
#undef printERR
#define printERR fprintf(stderr,"\r%s in line %d of %s: PROGRAM HALTED  \n",errormessage,ln,fn);fflush(stderr)
extern volatile int ln;
extern char * volatile fn;
extern const int cb(int lb, int ub, int index);
extern const char * cp(void);
extern const int ca(void);
extern const unsigned char sigNAN[8];


/* CPL interface to the termios functions needed to turn on and off ! */
/* character-by-character terminal input                            ! */
/*                                                                  ! */
/* Copyright 2002-2021 Paolo Luchini http://CPLcode.net             ! */
/* Released under the attached LICENSE.                             ! */
/*                                                                  ! */
/* Code maturity: green.                                            ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


#include <termios.h>
void CHARbyCHAR_1CHARbyCHAR(int descr_);
void CHARbyCHAR_2LINEbyLINE(void);

extern struct termios CHARbyCHAR_CHARbyCHAR_newsetting;
extern struct termios CHARbyCHAR_CHARbyCHAR_oldsetting;

extern int CHARbyCHAR_CHARbyCHAR_CbCdescr;

extern void CHARbyCHAR_1CHARbyCHAR(int descr_);


extern void CHARbyCHAR_2LINEbyLINE(void);

/* Library providing an interface to the select system call ! */
/* in order to detect if input is waiting to be read.       ! */
/* See infocpl INPUTREADY.                                  ! */
/*                                                          !  */
/* Copyright 2008-2020 Paolo Luchini http://CPLcode.net     ! */
/* Released under the attached LICENSE.                     ! */
/*                                                          ! */
/* Code maturity: green.                                    ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

extern int fd_input_ready(int fd, int sec, int usec);








extern int BlockLevel;

void singlestepper(int lineN_,char *line_);






extern FILE *rtchecks_SingleStep_grabin;

extern int rtchecks_SingleStep_StopLevel;
extern char rtchecks_SingleStep_LoopCount[(ssize_t)sizeof(int)*(100+1)];
extern int rtchecks_SingleStep_LastLine;

extern int rtchecks_SingleStep_paused;

extern int rtchecks_SingleStep_lastfnlength;
extern int rtchecks_SingleStep_lastrow;

extern char *rtchecks_SingleStep_lastfn;

extern int rtchecks_SingleStep_termwidth;
extern int rtchecks_SingleStep_termheight;

extern char *rtchecks_SingleStep_hotkeys;


extern void rtchecks_SingleStep_1RestoreScroll(void);


extern void TRON(void);


extern void singlestepper(int lineN_,char *line_);


extern int iproc_;
extern int nproc_;

/* iproc=number of the present node; nproc=total number of (distributed) nodes. */
extern FILE *prev_;
extern FILE *next_;

    
/* rbmatmod -- Copyright 2000 Paolo Luchini */
/* http://CPLcode.net/Applications/Numerical/rbmatmod/ */
/* */
/* parallel implementation of banded LU decomposition */
/* performs the solution of a banded linear system by the same algorithm used */
/* in rbmat.cpl. Each node in sequence solves a portion of the system and passes */
/* boundary data to the next node. */

/* Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE. */


/**/
void rbmatmod_1LUdecompStep(const int A_l,const int A_h,const ssize_t A_i,char *A__){char* volatile savefn; volatile int saveln; savefn=fn; saveln=ln; fn="/home/luchini/html/CPLcode.net/Applications/Numerical/rbmatmod/rbmatmod.cpl";{struct freefunc* es=freestack;
  double piv_;

  ln=31;if( ((next_==NULL)) ){ ssize_t _2st;
ssize_t _3st;
ln=29;_2st=(-2)*(ssize_t)sizeof(double);
memset(_2st+cb(A_l,A_h,A_h)*A_i+A__,0,(ssize_t)sizeof(double)*(2-(-2)+1)); ln=29;_3st=(-2)*(ssize_t)sizeof(double);
memset(_3st+cb(A_l,A_h,A_h-1)*A_i+A__,0,(ssize_t)sizeof(double)*(2-(-2)+1)); cb((-2),2,0+(1)*(1));cb((-2),2,0+(1)*(2));memset((ssize_t)sizeof(double)+cb(A_l,A_h,A_h-2)*A_i+A__,0,(ssize_t)sizeof(double)*2); (*(double *)(cb((-2),2,2)*(ssize_t)sizeof(double)+cb(A_l,A_h,A_h-3)*A_i+A__))=0.;}else{
    ssize_t _4st;
ln=30;_4st=(-2)*(ssize_t)sizeof(double);
ln=30;  if(!(fread(_4st+cb(A_l,A_h,A_h-1)*A_i+A__,(ssize_t)sizeof(double)*(2-(-2)+1),1, next_ )==1&&fread(_4st+cb(A_l,A_h,A_h)*A_i+A__,(ssize_t)sizeof(double)*(2-(-2)+1),1, next_ )==1))ioerr( next_ );
  };
  memmove(&piv_,&sigNAN,sizeof(double));ln=41; {int i_=A_h-2  ;while(i_>=A_l){
    ln=38; {int k_=2  ;while(k_>=1){
      char *j_5;char *j_6;

      ln=35;j_5=k_*(ssize_t)sizeof(double)+cb(A_l,A_h,i_)*A_i+A__;j_6=cb(A_l,A_h,i_+k_)*A_i+A__;ln=36;piv_=(*(double *)(j_5));
      ln=37; {int _t7= - (-2) ;do{{ ln=37;j_5=-(ssize_t)sizeof(double)+j_5;j_6=-(ssize_t)sizeof(double)+j_6;  (*(double *)(j_5))-=piv_*(*(double *)(j_6) );}_t7--;}while(_t7>0);}
    k_-=1;}}
    ln=39;piv_=1./(*(double *)(cb((-2),2,0)*(ssize_t)sizeof(double)+cb(A_l,A_h,i_)*A_i+A__));  (*(double *)(cb((-2),2,0)*(ssize_t)sizeof(double)+cb(A_l,A_h,i_)*A_i+A__))=piv_;
    cb((-2),2,0+(1)*((-2)));cb((-2),2,0+(1)*( -1));ln=40; {char *j_=(-2)*(ssize_t)sizeof(double)+cb(A_l,A_h,i_)*A_i+A__;int j_1=-1-(-2);  while(j_1>=0){ (*(double *)(j_))*=piv_;j_+=(ssize_t)sizeof(double);j_1--;}}
  i_-=1;}}
  ln=44;if( ((prev_==NULL)) ){ ssize_t _9st;
cb((-2),2,0+(1)*( -2));cb((-2),2,0+(1)*( -1));ln=42;_9st=(-2)*(ssize_t)sizeof(double);
memset(_9st+cb(A_l,A_h,A_l)*A_i+A__,0,(ssize_t)sizeof(double)*(-1-(-2)+1)); (*(double *)(cb((-2),2, - 2)*(ssize_t)sizeof(double)+cb(A_l,A_h,A_l+1)*A_i+A__))=0.;}else{
    ssize_t _10st;
ln=43;_10st=(-2)*(ssize_t)sizeof(double);
ln=43;fwrite(_10st+cb(A_l,A_h,A_l)*A_i+A__,(ssize_t)sizeof(double)*(2-(-2)+1),1,prev_);fwrite(_10st+cb(A_l,A_h,A_l+1)*A_i+A__,(ssize_t)sizeof(double)*(2-(-2)+1),1,prev_);
  };
}fn=savefn; ln=saveln;}

void rbmatmod_2LeftLUDivStep1(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__,const int t_l,const int t_h,const ssize_t t_i,char *t__){char* volatile savefn; volatile int saveln; savefn=fn; saveln=ln; fn="/home/luchini/html/CPLcode.net/Applications/Numerical/rbmatmod/rbmatmod.cpl";{struct freefunc* es=freestack;
  ln=48;if( !((next_==NULL)) ){   if(!(fread((double *)(cb(x_l,x_h,x_h-1)*x_i+x__),(ssize_t)sizeof(double),1, next_ )==1&&fread((double *)(cb(x_l,x_h,x_h)*x_i+x__),(ssize_t)sizeof(double),1, next_ )==1))ioerr( next_ );};
  ln=54; {int i_=A_h-2  ;while(i_>=A_l){
    char *j_3;char *j_4;

    double sum_;

    ln=50;j_3=2*(ssize_t)sizeof(double)+cb(A_l,A_h,i_)*A_i+A__;j_4=2*x_i+i_*x_i+x__;ln=51;sum_=(*(double *)(cb(t_l,t_h,i_)*t_i+t__));ln=52; {int _t5=2 ;while(_t5>0){ sum_-=(*(double *)(j_3))*(*(double *)(j_4)); j_3=-(ssize_t)sizeof(double)+j_3;j_4=-x_i+j_4;_t5--;}}
    ln=53;(*(double *)(j_4))=sum_*(*(double *)(j_3));
  i_-=1;}}
  ln=55;if( !((prev_==NULL)) ){ fwrite((double*)(cb(x_l,x_h,x_l+2)*x_i+x__),(ssize_t)sizeof(double),1,prev_);fwrite((double*)(cb(x_l,x_h,x_l+3)*x_i+x__),(ssize_t)sizeof(double),1,prev_);};
}fn=savefn; ln=saveln;}



void rbmatmod_3LeftLUDivStep2(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__){char* volatile savefn; volatile int saveln; savefn=fn; saveln=ln; fn="/home/luchini/html/CPLcode.net/Applications/Numerical/rbmatmod/rbmatmod.cpl";{struct freefunc* es=freestack;
  ln=61;if( !((prev_==NULL)) ){   if(!(fread((double *)(cb(x_l,x_h,x_l)*x_i+x__),(ssize_t)sizeof(double),1, prev_ )==1&&fread((double *)(cb(x_l,x_h,x_l+1)*x_i+x__),(ssize_t)sizeof(double),1, prev_ )==1))ioerr( prev_ );};
  ln=67; {int i_=A_l  ;while(i_<=A_h){
    char *j_4;char *j_5;

    double sum_;

    ln=63;j_4=(-2)*(ssize_t)sizeof(double)+cb(A_l,A_h,i_)*A_i+A__;j_5=(-2)*x_i+i_*x_i+x__;ln=64;sum_=0.;ln=65; {int _t6= - (-2) ;while(_t6>0){ sum_+=(*(double *)(j_4))*(*(double *)(j_5)); j_4=(ssize_t)sizeof(double)+j_4;j_5=x_i+j_5;_t6--;}}
    ln=66;(*(double *)(j_5))-=sum_;
  i_+=1;}}
  ln=68;if( !((next_==NULL)) ){ fwrite((double*)(cb(x_l,x_h,x_h-3)*x_i+x__),(ssize_t)sizeof(double),1,next_);fwrite((double*)(cb(x_l,x_h,x_h-2)*x_i+x__),(ssize_t)sizeof(double),1,next_);};
}fn=savefn; ln=saveln;}



void rbmatmod_4RightLUDivStep1(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int t_l,const int t_h,const ssize_t t_i,char *t__,const int A_l,const int A_h,const ssize_t A_i,char *A__){char* volatile savefn; volatile int saveln; savefn=fn; saveln=ln; fn="/home/luchini/html/CPLcode.net/Applications/Numerical/rbmatmod/rbmatmod.cpl";{struct freefunc* es=freestack;
  ln=74;if( !((next_==NULL)) ){   if(!(fread((double *)(cb(x_l,x_h,x_h-1)*x_i+x__),(ssize_t)sizeof(double),1, next_ )==1&&fread((double *)(cb(x_l,x_h,x_h)*x_i+x__),(ssize_t)sizeof(double),1, next_ )==1))ioerr( next_ );};
  ln=79; {int i_=A_h-2  ;while(i_>=A_l){
    double sum_;

    ln=76;sum_=(*(double *)(cb(t_l,t_h,i_)*t_i+t__));ln=77; {int j_=(-2)  ;do{{ ln=77;sum_-=(*(double *)(cb((-2),2,j_)*(ssize_t)sizeof(double)+cb(A_l,A_h,i_-j_)*A_i+A__))*(*(double *)(cb(x_l,x_h,i_-j_)*x_i+x__) );}j_+=1;}while(j_<= - 1);}
    ln=78;(*(double *)(cb(x_l,x_h,i_)*x_i+x__))=sum_;
  i_-=1;}}
  ln=80;if( !((prev_==NULL)) ){ fwrite((double*)(cb(x_l,x_h,x_l+2)*x_i+x__),(ssize_t)sizeof(double),1,prev_);fwrite((double*)(cb(x_l,x_h,x_l+3)*x_i+x__),(ssize_t)sizeof(double),1,prev_);};
}fn=savefn; ln=saveln;}

void rbmatmod_5RightLUDivStep2(const int x_l,const int x_h,const ssize_t x_i,char *x__,const int A_l,const int A_h,const ssize_t A_i,char *A__){char* volatile savefn; volatile int saveln; savefn=fn; saveln=ln; fn="/home/luchini/html/CPLcode.net/Applications/Numerical/rbmatmod/rbmatmod.cpl";{struct freefunc* es=freestack;
  ln=84;if( !((prev_==NULL)) ){   if(!(fread((double *)(cb(x_l,x_h,x_l)*x_i+x__),(ssize_t)sizeof(double),1, prev_ )==1&&fread((double *)(cb(x_l,x_h,x_l+1)*x_i+x__),(ssize_t)sizeof(double),1, prev_ )==1&&fread((double *)(cb(x_l,x_h,x_l+2)*x_i+x__),(ssize_t)sizeof(double),1, prev_ )==1&&fread((double *)(cb(x_l,x_h,x_l+3)*x_i+x__),(ssize_t)sizeof(double),1, prev_ )==1))ioerr( prev_ );};
  ln=90; {int i_=A_l  ;while(i_<=A_h-2){
    char *j_6;char *j_7;

    double _8p;
ln=86;j_6=cb(A_l,A_h,i_)*A_i+A__;j_7=i_*x_i+x__;ln=87;_8p=(*(double *)(j_7))*(*(double *)(cb((-2),2,0)*(ssize_t)sizeof(double)+cb(A_l,A_h,i_)*A_i+A__));
ln=87; 
    ln=88;(*(double *)(j_7))=_8p;
    ln=89; {int _t9=2 ;do{{ ln=89;j_6=(ssize_t)sizeof(double)+j_6;j_7=x_i+j_7;  (*(double *)(j_7))-=(*(double *)(j_6))*_8p ;}_t9--;}while(_t9>0);}
  i_+=1;}}
  ln=95;if( !((next_==NULL)) ){
    ln=92;fwrite((double*)(cb(x_l,x_h,x_h-3)*x_i+x__),(ssize_t)sizeof(double),1,next_);fwrite((double*)(cb(x_l,x_h,x_h-2)*x_i+x__),(ssize_t)sizeof(double),1,next_);fwrite((double*)(cb(x_l,x_h,x_h-1)*x_i+x__),(ssize_t)sizeof(double),1,next_);fwrite((double*)(cb(x_l,x_h,x_h)*x_i+x__),(ssize_t)sizeof(double),1,next_);
    ln=93;(*(double *)(cb(x_l,x_h,x_h-1)*x_i+x__))*=(*(double *)(cb((-2),2,0)*(ssize_t)sizeof(double)+cb(A_l,A_h,A_h-1)*A_i+A__));
    ln=94;(*(double *)(cb(x_l,x_h,x_h)*x_i+x__))=((*(double *)(cb(x_l,x_h,x_h)*x_i+x__))-(*(double *)(cb((-2),2,1)*(ssize_t)sizeof(double)+cb(A_l,A_h,A_h-1)*A_i+A__))*(*(double *)(cb(x_l,x_h,x_h-1)*x_i+x__)))*(*(double *)(cb((-2),2,0)*(ssize_t)sizeof(double)+cb(A_l,A_h,A_h)*A_i+A__));
  };
}fn=savefn; ln=saveln;}
